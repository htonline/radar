package com.example.thread;

import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import android.R.integer;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.Toast;

import com.example.customizingViews.ColoursView;

public class ReadThread implements Runnable {
    public Thread t;
    boolean suspended = false;
    public Handler handler = null;
    public static final int Const_NUMBEROFDATA = 512;

    Bundle bundle = new Bundle();
    short arrayListOfColour[] = new short[Const_NUMBEROFDATA];
    //��¼��ǰ�����ǵڼ���
    private int numberOfLogo;
    //��¼ʵ���յ����ٵ�����
    private int numberOfReceive = 0;
    ArrayList<byte[]> arrayListOfBytes = null;
    DatagramSocket ds = null;
    DatagramPacket dp = null;
    byte b1[] = new byte[1036];

    Message message = null;
    byte receive[] = new byte[4];
    byte receiveCC[] = new byte[2];
    private int judge_creatLink = 0;
    private int judge_cc_Mart = 0;
    private int judge_startSetting = 0;
    private int judge_endSetting = 0;
    private int judge_startCollect = 0;
    private int judge_suspendCollect = 0;
    private int judge_continueCollect = 0;
    private int judge_stopCollect = 0;
    private boolean judge = true;
    byte creatLink[] = {(byte) 0xaa, (byte) 0xaa, (byte) 0x01, 0x00};
    byte startSetting[] = {(byte) 0xaa, (byte) 0xaa, (byte) 0x02, 0x00};
    byte endSetting[] = {(byte) 0xaa, (byte) 0xaa, (byte) 0x04, 0x00};
    byte startCollect[] = {(byte) 0xaa, (byte) 0xaa, (byte) 0x08, 0x00};
    byte suspendCollect[] = {(byte) 0xaa, (byte) 0xaa, (byte) 0x10, 0x00};
    byte continueCollect[] = {(byte) 0xaa, (byte) 0xaa, (byte) 0x20, 0x00};
    byte stopCollect[] = {(byte) 0xaa, (byte) 0xaa, (byte) 0x40, 0x00};
    byte martCC[] = {(byte) 0xcc,(byte)0xcc};

    int status[] = new int[10];
    int number[] = new int[10];
    int index = 0;

    public ReadThread(DatagramSocket ds) {
        this.ds = ds;
        init();
    }

    public void init() {

//    	try {
//    		if (ds==null) {
//    			ds=new DatagramSocket(null);
//    			ds.setReuseAddress(true);
//    			ds.bind(new InetSocketAddress(6000));
//			}
        dp = new DatagramPacket(b1, b1.length);
//		} catch (SocketException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}


    }


    public void run() {
        while (true) {
            if (judge) {
                try {
//        			ds.setSoTimeout(2000); 
                    ds.receive(dp);
//    				Log.e("(((((((((((((((", Arrays.toString(b1));
                    System.arraycopy(b1, 0, receive, 0, 4);
                    System.arraycopy(b1,0,receiveCC,0,2);
                    if (Arrays.equals(receive, creatLink)) {
                        judge_creatLink++;
                    } else if (Arrays.equals(receive, startSetting)) {
                        judge_startSetting++;
                    } else if (Arrays.equals(receive, endSetting)) {
                        judge_endSetting++;
                    } else if (Arrays.equals(receive, startCollect)) {
                        judge_startCollect++;
                    } else if (Arrays.equals(receive, suspendCollect)) {
                        judge_suspendCollect++;
                    } else if (Arrays.equals(receive, continueCollect)) {
                        judge_continueCollect++;
                    } else if (Arrays.equals(receive, stopCollect)) {
                        judge_stopCollect++;
                    } else if(Arrays.equals(receiveCC,martCC)){
                        arrayListOfColour = new short[512];
//                        judge_cc_Mart++;
                        message = Message.obtain();
                        message.what = 6;
//                        message.arg1 = judge_cc_Mart;
                        message.obj = arrayListOfColour;
                        handler.sendMessage(message);
                    }
                    else //if (receive[0]==0xee&&receive[1]==0xee){
                    {
                        arrayListOfColour = toShortArray(Arrays.copyOfRange(b1, 10, 1034));
                        numberOfLogo = bytesToInt(Arrays.copyOfRange(b1, 4, 8), 0);
                        for (int k = 0; k < Const_NUMBEROFDATA; k++) {
                            arrayListOfColour[k] = LowToShort(arrayListOfColour[k]);
                        }
                        numberOfReceive++;
                        message = Message.obtain();
                        message.what = 0;
                        message.arg1 = numberOfLogo;
                        message.arg2 = numberOfReceive;
                        message.obj = arrayListOfColour;
                        handler.sendMessage(message);
                    }
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }
            } else {
                break;
            }

            synchronized (this) {
                while (suspended) {
                    try {
                        wait();
                    } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                    }
                }
            }
        }


        //��ʼ�����ݣ��ȸ�10��byte���鶼����ֵ
//    		if (index==0) {
//    			for (i= 0; i<10; i++) {
//    				dp=new DatagramPacket(arrayListOfBytes.get(i), arrayListOfBytes.get(i).length);
//    				try {
//    					ds.receive(dp);
//    					System.arraycopy(arrayListOfBytes.get(i), 0, receive, 0, 5);
//    					if (Arrays.equals(receive, creatLink)) {
//							judge_creatLink++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, startSetting)) {
//							judge_startSetting++;
//							Log.d("--------------", "judge_startSetting"+judge_startSetting);
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, endSetting)) {
//							judge_endSetting++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, startCollect)) {
//							judge_startCollect++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, suspendCollect)) {
//							judge_suspendCollect++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, continueCollect)) {
//							judge_continueCollect++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, stopCollect)) {
//							judge_stopCollect++;
//							i--;
//							continue;
//						}else {					
//							number[i]=(int)(arrayListOfBytes.get(i)[2]);
//							status[i]=1;
//						}
//    				} catch (IOException e) {
//    					// TODO Auto-generated catch block
//    					e.printStackTrace();
//    				}
//    			}
//    			index++;
//			}
//    		
//    		    		
//    		//�ȱ������ϣ��ж�number[]�����С�ĵ���min��index��Ȳ��������ȣ���status[i]��Ϊ0������handler������Ϣ��
//    		//�������ȣ�index=min,�൱�ڶ�������ȥ�����ݰ���
//    		min=number[0];
//    		j=0;
//    		for (i = 0; i < 10;i++) {
//				if (min>number[i]) {
//					min=number[i];
//					j=i;
//				}
//			}
//    		if (index==min) {
//				status[j]=0;
//				
//				
//				arrayListOfColour=toShortArray(Arrays.copyOfRange(arrayListOfBytes.get(j), 6, 1030));
//				message.what=0;
//				message.obj=arrayListOfColour;
//				handler.sendMessage(message);
//				index++;
//			}else {
//				index=min;
//			}
//    		
//    		//�жϸ�byte�����ǲ���Ϊ�գ�Ϊ�ո���
//    		//��ʼ�ж�
//    		for (i = 0; i < 10; i++) {
//				if (status[i]==0) {
//					try {
//						dp=new DatagramPacket(arrayListOfBytes.get(i), arrayListOfBytes.get(i).length);
//						ds.receive(dp);
//						System.arraycopy(arrayListOfBytes.get(i), 0, receive, 0, 5);
//    					if (Arrays.equals(receive, creatLink)) {
//							judge_creatLink++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, startSetting)) {
//							judge_startSetting++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, endSetting)) {
//							judge_endSetting++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, startCollect)) {
//							judge_startCollect++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, suspendCollect)) {
//							judge_suspendCollect++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, continueCollect)) {
//							judge_continueCollect++;
//							i--;
//							continue;
//						}else if (Arrays.equals(receive, stopCollect)) {
//							judge_stopCollect++;
//							i--;
//							continue;
//						}else {					
//							number[i]=(int)(arrayListOfBytes.get(i)[2]);
//							status[i]=1;
//						}
//					} catch (IOException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//				}
//			}


    }

    public Handler getHandler() {
        return handler;
    }

    public void setHandler(Handler handler) {
        this.handler = handler;
    }

    public static short LowToShort(short a) {
        return (short) (((a & 0xFF) << 8) | ((a >> 8) & 0xFF));
    }


    /**
     * ��ʼ
     */
    public void start() {

        if (t == null) {
            t = new Thread(this);
            t.start();
        }
    }

    /**
     * ��ͣ
     */
    public void suspend() {
        suspended = true;
    }

    /**
     * ����
     */
    public synchronized void resume() {
        suspended = false;
        notify();
    }

    public static short[] toShortArray(byte[] src) {

        int count = src.length >> 1;
        short[] dest = new short[count];
        for (int i = 0; i < count; i++) {
            dest[i] = (short) (src[i * 2] << 8 | src[2 * i + 1] & 0xff);
        }
        return dest;
    }


    public int getNumberOfLogo() {
        return numberOfLogo;
    }

    public void setNumberOfLogo(int numberOfLogo) {
        this.numberOfLogo = numberOfLogo;
    }

    public int getJudge_cc_Mart() {
        return judge_cc_Mart;
    }

    public void setJudge_cc_Mart(int judge_cc_Mart) {
        this.judge_cc_Mart = judge_cc_Mart;
    }

    public int getNumberOfReceive() {
        return numberOfReceive;
    }

    public void setNumberOfReceive(int numberOfReceive) {
        this.numberOfReceive = numberOfReceive;
    }

    public boolean isJudge() {
        return judge;
    }

    public void setJudge(boolean judge) {
        this.judge = judge;
    }

    public int getJudge_creatLink() {
        return judge_creatLink;
    }

    public void setJudge_creatLink(int judge_creatLink) {
        this.judge_creatLink = judge_creatLink;
    }

    public int getJudge_startSetting() {
        return judge_startSetting;
    }

    public void setJudge_startSetting(int judge_startSetting) {
        this.judge_startSetting = judge_startSetting;
    }

    public int getJudge_endSetting() {
        return judge_endSetting;
    }

    public void setJudge_endSetting(int judge_endSetting) {
        this.judge_endSetting = judge_endSetting;
    }

    public int getJudge_startCollect() {
        return judge_startCollect;
    }

    public void setJudge_startCollect(int judge_startCollect) {
        this.judge_startCollect = judge_startCollect;
    }

    public int getJudge_suspendCollect() {
        return judge_suspendCollect;
    }

    public void setJudge_suspendCollect(int judge_suspendCollect) {
        this.judge_suspendCollect = judge_suspendCollect;
    }

    public int getJudge_continueCollect() {
        return judge_continueCollect;
    }

    public void setJudge_continueCollect(int judge_continueCollect) {
        this.judge_continueCollect = judge_continueCollect;
    }

    public int getJudge_stopCollect() {
        return judge_stopCollect;
    }

    public void setJudge_stopCollect(int judge_stopCollect) {
        this.judge_stopCollect = judge_stopCollect;
    }

    /**
     * byte������ȡint��ֵ��������������(��λ��ǰ����λ�ں�)��˳�򣬺ͺ�intToBytes��������ʹ��
     *
     * @param src    byte����
     * @param offset ������ĵ�offsetλ��ʼ
     * @return int��ֵ
     */
    public static int bytesToInt(byte[] src, int offset) {
        int value;
        value = (int) ((src[offset] & 0xFF)
                | ((src[offset + 1] & 0xFF) << 8)
                | ((src[offset + 2] & 0xFF) << 16)
                | ((src[offset + 3] & 0xFF) << 24));
        return value;
    }

    /**
     * byte������ȡint��ֵ��������������(��λ�ں󣬸�λ��ǰ)��˳�򡣺�intToBytes2��������ʹ��
     */
    public static int bytesToInt2(byte[] src, int offset) {
        int value;
        value = (int) (((src[offset] & 0xFF) << 24)
                | ((src[offset + 1] & 0xFF) << 16)
                | ((src[offset + 2] & 0xFF) << 8)
                | (src[offset + 3] & 0xFF));
        return value;
    }


}