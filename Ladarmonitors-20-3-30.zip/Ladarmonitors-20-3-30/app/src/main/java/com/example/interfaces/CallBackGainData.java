package com.example.interfaces;

public interface CallBackGainData {
	public void gainData(int [] gaindata,float [] xRaw);
}
