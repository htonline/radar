package com.example.helper;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.Iterator;

import android.content.Context;

public class SaveData {
	private String path;
	public static final int Const_NumberOfVerticalDatas=512;
	public short colorGap[]=new short [Const_NumberOfVerticalDatas];
	
	
	
	public SaveData(String path) {
		super();
		this.path = path;
	}


	public void printTitle() throws Exception {    
       FileOutputStream fos=null;
       try {
		fos=new FileOutputStream(path);
       } catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
       }
       BufferedOutputStream bos=new BufferedOutputStream(fos);
       short sig=(short)0x5555;
       int offeset=688;
       int trace_num=1;
       byte reverse []=new byte [100];
       try {
		bos.write(shortToByte(sig));
		bos.write(offeset);
		bos.write(trace_num);
		bos.write(reverse);
		bos.flush();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}finally{
		bos.close();
	}
    }    
	
	
	public void printData(short colorGap[] ) throws Exception{
		this.colorGap=colorGap;
		File file=new File(path);
		RandomAccessFile raf=new RandomAccessFile(file, "rw");
		raf.seek(file.length());
		raf.writeFloat(0);
		raf.writeFloat(0);
		raf.writeFloat(0);
		raf.write(0);
		for (int i = 0; i < colorGap.length; i++) {
			raf.writeShort(colorGap[i]);
		}
		raf.close();
	}
	
	
	/**  
	    * ��int��ֵת��Ϊռ�ĸ��ֽڵ�byte���飬������������(��λ�ں󣬸�λ��ǰ)��˳�� ��bytesToInt��������ʹ�� 
	    * @param value  
	    *            Ҫת����intֵ 
	    * @return byte���� 
	    */    
	
	public static byte[] intToBytes( int value )   
	{   
	    byte[] src = new byte[4];  
	    src[3] =  (byte) ((value>>24) & 0xFF);  
	    src[2] =  (byte) ((value>>16) & 0xFF);  
	    src[1] =  (byte) ((value>>8) & 0xFF);    
	    src[0] =  (byte) (value & 0xFF);                  
	    return src;   
	}  
	
	/*��intתΪ���ֽ���ǰ�����ֽ��ں��byte���� 
	b[0] = 11111111(0xff) & 01100001 
	b[1] = 11111111(0xff) & (n >> 8)00000000 
	b[2] = 11111111(0xff) & (n >> 8)00000000 
	b[3] = 11111111(0xff) & (n >> 8)00000000 
	*/  
	public byte[] IntToByteArray(int n) {    
	        byte[] b = new byte[4];    
	        b[0] = (byte) (n & 0xff);    
	        b[1] = (byte) (n >> 8 & 0xff);    
	        b[2] = (byte) (n >> 16 & 0xff);    
	        b[3] = (byte) (n >> 24 & 0xff);    
	        return b;    
	}  
	
	public static byte[] shortToByte(short number) { 
        int temp = number; 
        byte[] b = new byte[2]; 
        for (int i = 0; i < b.length; i++) { 
            b[i] = new Integer(temp & 0xff).byteValue();
            //�����λ���������λ 
            temp = temp >> 8; // ������8λ 
        } 
        return b; 
    } 
	
	
	
	
	
	 public static byte[] toByteArray(short[] src) {

	        int count = src.length;
	        byte[] dest = new byte[count << 1];
	        for (int i = 0; i < count; i++) {
	                dest[i * 2] = (byte) (src[i] >> 8);
	                dest[i * 2 + 1] = (byte) (src[i] >> 0);
	        }

	        return dest;
	    }
	 
	 /** 
	  * ����ת��Ϊ�ֽ� 
	  *  
	  * @param f 
	  * @return 
	  */  
	 public static byte[] floatToByte(float f) {  
	       
	     // ��floatת��Ϊbyte[]  
	     int fbit = Float.floatToIntBits(f);  
	       
	     byte[] b = new byte[4];    
	     for (int i = 0; i < 4; i++) {    
	         b[i] = (byte) (fbit >> (24 - i * 8));    
	     }   
	       
	     // ��ת����  
	     int len = b.length;  
	     // ����һ����Դ����Ԫ��������ͬ������  
	     byte[] dest = new byte[len];  
	     // Ϊ�˷�ֹ�޸�Դ���飬��Դ���鿽��һ�ݸ���  
	     System.arraycopy(b, 0, dest, 0, len);  
	     byte temp;  
	     // ��˳λ��i���뵹����i������  
	     for (int i = 0; i < len / 2; ++i) {  
	         temp = dest[i];  
	         dest[i] = dest[len - i - 1];  
	         dest[len - i - 1] = temp;  
	     }  
	       
	     return dest;  
	       
	 }  

}