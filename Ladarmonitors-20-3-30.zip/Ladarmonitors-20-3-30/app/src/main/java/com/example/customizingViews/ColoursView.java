package com.example.customizingViews;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import android.R.integer;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.text.TextPaint;
import android.util.AttributeSet;
import android.util.Log;
import android.view.SurfaceView;
import android.view.View;

public class ColoursView extends View{
	public ColoursView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
//		init();
		// TODO Auto-generated constructor stub
	}
	
	public ColoursView(Context context, AttributeSet attrs) {
		this(context, attrs, 0);
		// TODO Auto-generated constructor stub
	}

	public ColoursView(Context context) {
		this(context, null);
		// TODO Auto-generated constructor stub
	}
	
	//����Դ,��ߵ�ֵ��int��16������
//	private ArrayList<Integer> coloursDataList=null;
	//�ʣ���������
	private Paint pointPaint=null;
	//�ʣ�����������������
	private TextPaint yTextPaint=null;
	//�ʣ���������Y������
	private Paint yPaint=null;
	
	
	public int viewWidth=1200;
	public int viewHeight=732;
	public int drawWidth;
	public int drawHeight;
	public float scale;
	private Bitmap bitmap=null;
	private int currentVertical=0;
	
	//�ܵ�����List
//	private ArrayList<ArrayList<Integer>> listOfAllData=null;
	
	//�����м�� line
	private float floatl=0;
	//�����м�� arrange
	private int inta=0;
	//Ԥ��Y����ʾ��Ϣ����
	private int intY=0;
	//Ԥ��X����ʾ��Ϣ�߶�
	private int intX=0;
	//���������߳���
	private int intXx=0;
	//�����(����������)
	Random random=null;
	//����м���list����
//	private int index=0;
	//�ж�Ӧ���滻��������(0���ӣ�����0�滻)
//	private int judge=0;
	
//	//��ȡview����
//	private int viewHeight=getHeight();
//	private int viewWidth=getWidth();
	
//	public ArrayList<Integer> getList(){
//		return coloursDataList;
//	}
//	
//	public void setList(ArrayList<Integer> coloursDataList){
//		Log.d("11111111111", "in");
//		this.coloursDataList=coloursDataList;
//		if (judge==0) {
//			listOfAllData.add(index,coloursDataList);
//			Log.d("2222222222", index+"");
//		}else {
//			listOfAllData.set(index,coloursDataList);
//		}
//		if (getIndex()==700) {
//			setIndex(0);
//			judge++;
//		}else 
//			setIndex(++index);
//		invalidate();
//	}
//
//	public int getIndex() {
//		return index;
//	}
//
//	public void setIndex(int index) {
//		this.index = index;
//	}
	
	//��ʼ��
	private void init(){
		pointPaint=new Paint();
		pointPaint.setAntiAlias(true);
		yTextPaint=new TextPaint();
		yTextPaint.setAntiAlias(true);
		yPaint=new Paint();
		yPaint.setAntiAlias(true);
		yPaint.setColor(0xff888888);
//		coloursDataList=new ArrayList<Integer>();
//		listOfAllData=new ArrayList<ArrayList<Integer>>();
		
//		floatl=getHeight()/25;
		inta=1;
		intY=50;
		intX=25;
		intXx=10;
	}
	
	@Override
	protected void onLayout(boolean changed, int left, int top, int right,
			int bottom) {
		// TODO Auto-generated method stub
		super.onLayout(changed, left, top, right, bottom);
		viewWidth=getWidth();
		viewHeight=getHeight();
		init();
		drawHeight=viewHeight-intX;
		drawWidth=(int) (viewWidth-32);
		if (drawHeight/512.0>1) {
			scale=(float) (512.0/drawHeight);
		}else {
			scale=(float) (drawHeight/512.0);		
		}
		bitmap=Bitmap.createBitmap(drawWidth,drawHeight, Bitmap.Config.RGB_565);
		//�����ɫ 
		bitmap.eraseColor(Color.parseColor("#FFFFFF")); 
	}
	
	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
		//��ȡ�������ұ߾�
//		int pl=getPaddingLeft();
//		int pr=getPaddingRight();
//		int pt=getPaddingTop();
//		int pb=getPaddingBottom();
		
		
		floatl=(viewHeight-intX)/25.0f;
		
		//����Y���X��
		for (int i = 0; i <= 25; i++) {
			if (i%5==0) {
				if (i!=25) {
					//�����ֵĺ���
					canvas.drawLine(0, viewHeight-(25-i)*floatl-intX, yTextPaint.measureText(2.0+"")+intXx+5, viewHeight-(25-i)*floatl-intX, yPaint);					
				}else {
					//X��
					canvas.drawLine(0, viewHeight-(25-i)*floatl-intX, viewWidth, viewHeight-(25-i)*floatl-intX, yPaint);
				}
				//��������
				canvas.drawText((double)(Math.round(i*0.08*10))/10+"", 0, viewHeight-(25-i)*floatl, yTextPaint);
			}else {
				//��̵ĺ���
				canvas.drawLine(yTextPaint.measureText(2.0+"")+5, viewHeight-(25-i)*floatl-intX, yTextPaint.measureText(2.0+"")+intXx+5, viewHeight-(25-i)*floatl-intX, yPaint);
			}
		}
		//Y��
		canvas.drawLine(yTextPaint.measureText(2.0+"")+intXx+5, 0, yTextPaint.measureText(2.0+"")+intXx+5, viewHeight, yPaint);
		canvas.drawBitmap(bitmap, 32, 0, pointPaint );

		
		
		//height,25		canvas.drawText(intX+"", 200, 200, yPaint);
//		canvas.drawText(yTextPaint.measureText(2.0+"")+intXx+5+"", 200, 200, yPaint);
		
		
//		canvas.drawText(viewHeight-intX+"", 200, 200, yTextPaint);
//		canvas.drawText(viewWidth-yTextPaint.measureText(2.0+"")-intXx-5+"", 200, 400, yTextPaint);
//		for(int j=0;j<15;j++){
//			for (int i = 0; i < 512; i++) {
//				coloursDataList.add(i,random.nextInt(255));
//			}
//				listOfAllData.add(j, coloursDataList);
//			
//		}
		
//		for(int j=0;j<listOfAllData.size();j++){
//			
//			for (int i = 0; i < coloursDataList.size(); i++) {
//				pointPaint.setColor(Color.rgb(listOfAllData.get(j).get(i), listOfAllData.get(j).get(i), listOfAllData.get(j).get(i)));
//				canvas.drawPoint(yTextPaint.measureText(2.0+"")+intXx+5+2*j+1, i*2, pointPaint);
//				canvas.drawPoint(yTextPaint.measureText(2.0+"")+intXx+5+2*j+2, i*2, pointPaint);
//				canvas.drawPoint(yTextPaint.measureText(2.0+"")+intXx+5+2*j+1, i*2+1, pointPaint);
//				canvas.drawPoint(yTextPaint.measureText(2.0+"")+intXx+5+2*j+2, i*2+1, pointPaint);
//			}
//			
//		}	
	}
	
	public void drawNewVertical(int[] colorList){
        for(int i=0;i<drawHeight;i++){
            bitmap.setPixel(currentVertical,i,colorList[(int) (i*scale)]);
            if (currentVertical<drawWidth-2) {
            	 bitmap.setPixel(currentVertical+1,i,0x0000FF);
			}
        }
        currentVertical++;
        if(currentVertical>=drawWidth){
            currentVertical=0;
        }
        this.invalidate();
    }

}
