package com.example.BackRadar;

import java.io.File;
import java.io.IOException;
import java.net.DatagramSocket;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;
import java.util.Map;
import java.util.Random;

import com.example.fragments.LeftFragmentOfSettingActivity;
import com.example.fragments.RightFragmentOfSettingActivity;
import com.example.helper.SaveData;
import com.example.interfaces.CallBackGainData;
import com.example.ladarmonitor.NoneActivity;
import com.example.ladarmonitor.R;
import com.example.orders.MainPeremeterOrders;
import com.example.orders.NormalOrders;
import com.example.thread.ReadThread;

import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Message;
import android.provider.ContactsContract.CommonDataKinds.Event;
import android.R.integer;
import android.R.string;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnFocusChangeListener;
import android.view.View.OnKeyListener;
import android.view.Window;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.TextView.OnEditorActionListener;
import android.widget.Toast;

public class SettingActivity extends Activity{
	
	public LeftFragmentOfSettingActivity leftFragmentOfSettingActivity;
	public RightFragmentOfSettingActivity rightFragmentOfSettingActivity;
	public static final int Const_NumberOfVerticalDatas=512;
	public static final int Const_NumberOfXRawDatas=17;
	public short colorGap[]=new short [Const_NumberOfVerticalDatas];
	public int gainData[]=new int [Const_NumberOfVerticalDatas];
	public float xRaw[]=new float [17];
	
	//�Զ����ð�ť��ͣ�жϼ�����
	boolean judge_automaticSetting=false;
	//ˮƽ�����ж�
	int counteOfHorizontalGain=0;
	
	//�ļ�����
	public static final String type=".raw";
	//Ĭ��·��
	public static final String defaultPath="/sdcard/datas";
	
	//�洢·��,���ȷ����ť����Ҫ�������ַ����MainActivity���ɼ����ݵ�ͬʱ�����ݱ��������·����
	private String path=null;
	//�ļ��������ȷ����ť����Ҫ�������ַ����MainActivity���ɼ����ݵ�ͬʱ�����ݱ���������ļ�����
	private String fileName=".raw";
	private Button btn_creatPath=null;
	private TextView tv_settingPath=null;
	private EditText et_nameOfMainFile=null;
	private EditText et_serialNumberOfFile=null;
	private TextView tv_storeFile=null;
	private TextView tv_none=null;
	private Spinner sp_frequency=null;
	private int frequency=0;
	
//	private Spinner sp_oneWay=null;
	private EditText et_timeWindow=null;
	private EditText et_delay=null;
	private List<Integer> listOfFrequency=null;
//	private List<String> listOfTheWayOfPulse=null;
	private ArrayAdapter<Integer> adapterOfFrequency=null;
//	private ArrayAdapter<String> adapterOfTheWayOfPulse=null;
	private RadioButton rd_timing=null;
	private RadioButton rd_wheel=null;
	private RadioButton rd_oneWay=null;
	private RadioButton rd_twoWays=null;
	private EditText et_numberOfPulse=null;
	private EditText et_singlePulse=null;
	private EditText et_singleDistance=null;
	private EditText et_samplingInterval=null;
	
	//startActivityForResult
	public static final int FILE_RESULT_CODE = 1;
	
	SharedPreferences mainPeremeterOrders=null;
	
	//��ǰϵͳʱ���������ʱ��
	private int mYear;
	private int mMonth;
	private int mDay;
	private int mHour;
	private int mMinute;
	private Calendar calendar=null;
	
	//�ж��ļ��Ƿ����
	File file=null;
	
	//�洢������
	SharedPreferences.Editor mainPeremeterOrdersEditor=null;
	
	static SaveData saveData=null;
	
	//���͵�����
	NormalOrders nOrders=null;
	MainPeremeterOrders pOrders=null;
	
    byte startSetting []={(byte) 0xaa,(byte) 0xaa,(byte) 0x02,0x00};
    byte endSetting []={(byte) 0xaa,(byte) 0xaa,(byte) 0x04,0x00};
    byte startCollect []={(byte) 0xaa,(byte) 0xaa,(byte) 0x08,0x00};
    byte suspendCollect []={(byte) 0xaa,(byte) 0xaa,(byte) 0x10,0x00};
    byte continueCollect []={(byte) 0xaa,(byte) 0xaa,(byte) 0x20,0x00};
    byte stopCollect []={(byte) 0xaa,(byte) 0xaa,(byte) 0x40,0x00};
 
    //����readThread���ջ��������ݣ�����ui
	private Handler handlerOfColour=new Handler(){
        @Override
        public void handleMessage(Message msg) {
        	switch (msg.what) {
			case 0:
				colorGap=(short[]) msg.obj;
				for (int i = 0; i < Const_NumberOfVerticalDatas; i++) {
					colorGap[i]=(short) (colorGap[i]/256);
				}
				rightFragmentOfSettingActivity.drawRadarWave(colorGap,gainData);	
				break;
			case 1:
				if (Integer.parseInt(et_delay.getText().toString())>=10000) {
					et_delay.setText("100");
				}else {
					et_delay.setText(Integer.parseInt(et_delay.getText().toString())+100+"");					
				}
				pOrders.setDelay_time_DELAY(Short.parseShort(et_delay.getText().toString()));
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						pOrders.send();
					}
				}).start();
				break;
			default:
				break;
			}
        }
    };
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_setting);
		try {
			init();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		rd_timing.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				rd_oneWay.setEnabled(false);
				rd_twoWays.setEnabled(false);
//				sp_oneWay.setSelection(0);
//				sp_oneWay.setEnabled(false);
				rd_oneWay.setChecked(false);
				rd_twoWays.setChecked(false);
				//����������ܵ��
				et_numberOfPulse.setEnabled(false);
				et_singleDistance.setEnabled(false);
				et_singlePulse.setEnabled(false);
				pOrders.setTriggerMode(0);
				
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						pOrders.send();
					}
				}).start();
			}
		});
		
		rd_wheel.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				rd_oneWay.setEnabled(true);
				rd_twoWays.setEnabled(true);
				pOrders.setTriggerMode(1);
////				sp_oneWay.setSelection(0);
//				//����������Ե��
				et_numberOfPulse.setEnabled(true);
				et_singleDistance.setEnabled(true);
				et_singlePulse.setEnabled(true);
				
				//Ĭ��ѡ�е��򴥷�
				rd_oneWay.setChecked(true);
				pOrders.setTriggerDirection(0);
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						pOrders.send();
					}
				}).start();
			}
		});
		
		rd_oneWay.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
//				sp_oneWay.setEnabled(true);
				pOrders.setTriggerDirection(0);
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						pOrders.send();
					}
				}).start();
			}
		});
		
		rd_twoWays.setOnClickListener(new View.OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
//				sp_oneWay.setEnabled(false);
				pOrders.setTriggerDirection(1);
//				sp_oneWay.setSelection(0);
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						pOrders.send();
					}
				}).start();
			}
		});
		
		
		
		
//		et_nameOfMainFile.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				// TODO Auto-generated method stub
//				if (et_nameOfMainFile.getText().toString().equals("")) {
//					Toast.makeText(SettingActivity.this, "���ļ�������Ϊ��", Toast.LENGTH_SHORT).show();
//					et_nameOfMainFile.setText("file");
//				}				
//				tv_storeFile.setText(et_nameOfMainFile.getText().toString()+et_serialNumberOfFile.getText().toString()+type);
//				if (tv_settingPath.getText().toString().equals("")) {
//					
//				}else {
//					path=tv_settingPath.getText().toString()+"/"+tv_storeFile.getText().toString();
//					Toast.makeText(SettingActivity.this, "path:"+path, Toast.LENGTH_LONG).show();
//				}
//				return false;
//			}
//		});
		
		//�ļ����ı���
		et_nameOfMainFile.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				if (actionId==EditorInfo.IME_ACTION_DONE) {
					if (et_nameOfMainFile.getText().toString().equals("")) {
						Toast.makeText(SettingActivity.this, "���ļ�������Ϊ��", Toast.LENGTH_SHORT).show();
						et_nameOfMainFile.setText("file");
					}				
					tv_storeFile.setText(et_nameOfMainFile.getText().toString()+et_serialNumberOfFile.getText().toString()+type);
					
				}
				tv_none.setFocusable(true);
				tv_none.setFocusableInTouchMode(true);
				tv_none.requestFocus();
				return false;
			}
		});
		et_nameOfMainFile.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if (hasFocus) {
					
				}else {
					InputMethodManager imm = (InputMethodManager) getSystemService(SettingActivity.INPUT_METHOD_SERVICE);
	                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
					Intent intent = new Intent(SettingActivity.this,NoneActivity.class);
					startActivity(intent);
				}
			}
		});
		
		
		
//		et_serialNumberOfFile.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				// TODO Auto-generated method stub
//				if (et_serialNumberOfFile.getText().toString().equals("")) {
//					Toast.makeText(SettingActivity.this, "�ļ���Ų���Ϊ��", Toast.LENGTH_SHORT).show();
//					et_serialNumberOfFile.setText("1");
//				}
//				tv_storeFile.setText(et_nameOfMainFile.getText().toString()+et_serialNumberOfFile.getText().toString()+type);
//				if (tv_settingPath.getText().toString().equals("")) {
//					
//				}else {
//					path=tv_settingPath.getText().toString()+"/"+tv_storeFile.getText().toString();
//					Toast.makeText(SettingActivity.this, "path:"+path, Toast.LENGTH_LONG).show();
//				}
//				return false;
//			}
//		});
		//�ļ��Ÿı���
		et_serialNumberOfFile.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				if (actionId==EditorInfo.IME_ACTION_DONE) {
					if (et_serialNumberOfFile.getText().toString().equals("")) {
						Toast.makeText(SettingActivity.this, "�ļ���Ų���Ϊ��", Toast.LENGTH_SHORT).show();
						et_serialNumberOfFile.setText("1");
					}
					tv_storeFile.setText(et_nameOfMainFile.getText().toString()+et_serialNumberOfFile.getText().toString()+type);
					
					tv_none.setFocusable(true);
					tv_none.setFocusableInTouchMode(true);
					tv_none.requestFocus();
				}
				return false;
			}
		});
		et_serialNumberOfFile.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if (hasFocus) {
					
				}else {
					InputMethodManager imm = (InputMethodManager) getSystemService(SettingActivity.INPUT_METHOD_SERVICE);
	                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
					Intent intent = new Intent(SettingActivity.this,NoneActivity.class);
					startActivity(intent);
				}
			}
		});
		
		
		
		//�����������ı����
		et_numberOfPulse.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				
				int numberOfPulse=Integer.parseInt(et_numberOfPulse.getText().toString());
				int singlePulse=Integer.parseInt(et_singlePulse.getText().toString());
				float singleDistance=Float.parseFloat(et_singleDistance.getText().toString());
				if (actionId==EditorInfo.IME_ACTION_DONE) {
					if (et_numberOfPulse.getText().toString().equals("")) {
						Toast.makeText(SettingActivity.this, "��������������Ϊ��", Toast.LENGTH_SHORT).show();
						et_numberOfPulse.setText("1");
					}else if (Integer.parseInt(et_numberOfPulse.getText().toString())<=0) {
						Toast.makeText(SettingActivity.this, "��������������Ϊ������0�ķǸ���", Toast.LENGTH_SHORT).show();
						et_numberOfPulse.setText("1");
					}
					
					tv_none.setFocusable(true);
					tv_none.setFocusableInTouchMode(true);
					tv_none.requestFocus();
					
					numberOfPulse=Integer.parseInt(et_numberOfPulse.getText().toString());
					et_samplingInterval.setText(String.valueOf(singleDistance*numberOfPulse/singlePulse));
					pOrders.setNumberOfPulse(Integer.parseInt(et_numberOfPulse.getText().toString()));
				}
				return false;
			}
		});
		
		et_numberOfPulse.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if (hasFocus) {
					
				}else {
					InputMethodManager imm = (InputMethodManager) getSystemService(SettingActivity.INPUT_METHOD_SERVICE);
	                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
					Intent intent = new Intent(SettingActivity.this,NoneActivity.class);
					startActivity(intent);
				}
			}
		});
		
//		et_numberOfPulse.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				// TODO Auto-generated method stub
//				int numberOfPulse=Integer.parseInt(et_numberOfPulse.getText().toString());
//				int singlePulse=Integer.parseInt(et_singlePulse.getText().toString());
//				float singleDistance=Float.parseFloat(et_singleDistance.getText().toString());
//				if (et_numberOfPulse.getText().toString().equals("")) {
//					Toast.makeText(SettingActivity.this, "��������������Ϊ��", Toast.LENGTH_SHORT).show();
//					et_numberOfPulse.setText("20");
//				}if (Integer.parseInt(et_numberOfPulse.getText().toString())<=0) {
//					Toast.makeText(SettingActivity.this, "��������������С�ڵ���0", Toast.LENGTH_SHORT).show();
//					et_numberOfPulse.setText("20");
//				}
//					
//					numberOfPulse=Integer.parseInt(et_numberOfPulse.getText().toString());
//					et_samplingInterval.setText(String.valueOf(singleDistance*numberOfPulse/singlePulse));
//					pOrders.setNumberOfPulse(Integer.parseInt(et_numberOfPulse.getText().toString()));
//				
////				mainPeremeterOrdersEditor.putInt("numberOfPulse",numberOfPulse );
//				
//				return false;
//			}
//		});

		et_singleDistance.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				
				int numberOfPulse=Integer.parseInt(et_numberOfPulse.getText().toString());
				int singlePulse=Integer.parseInt(et_singlePulse.getText().toString());
				float singleDistance=Float.parseFloat(et_singleDistance.getText().toString());
				if (actionId==EditorInfo.IME_ACTION_DONE) {
					if (Integer.parseInt(et_singleDistance.getText().toString())<=0) {
						Toast.makeText(SettingActivity.this, "��Ȧ�������Ϊ������0�ķǸ���", Toast.LENGTH_SHORT).show();
						et_singleDistance.setText("0.30");
					}else if (et_singleDistance.getText().toString().equals("")) {
						Toast.makeText(SettingActivity.this, "��Ȧ���벻��Ϊ��", Toast.LENGTH_SHORT).show();
						et_singleDistance.setText("0.30");
						
					}
					
					tv_none.setFocusable(true);
					tv_none.setFocusableInTouchMode(true);
					tv_none.requestFocus();
					
					singleDistance=Float.parseFloat(et_singleDistance.getText().toString());
					et_samplingInterval.setText(String.valueOf(singleDistance*numberOfPulse/singlePulse));
				}
				return false;
			}
		});
		
		et_singleDistance.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if (hasFocus) {
					
				}else {
					InputMethodManager imm = (InputMethodManager) getSystemService(SettingActivity.INPUT_METHOD_SERVICE);
	                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
					Intent intent = new Intent(SettingActivity.this,NoneActivity.class);
					startActivity(intent);
				}
			}
		});
		
//		et_singleDistance.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				// TODO Auto-generated method stub
//				int numberOfPulse=Integer.parseInt(et_numberOfPulse.getText().toString());
//				int singlePulse=Integer.parseInt(et_singlePulse.getText().toString());
//				float singleDistance=Float.parseFloat(et_singleDistance.getText().toString());
//				if (Integer.parseInt(et_singleDistance.getText().toString())==0) {
//					Toast.makeText(SettingActivity.this, "��Ȧ���벻��Ϊ0", Toast.LENGTH_SHORT).show();
//					et_singleDistance.setText("0.52");
//				}else if (et_singleDistance.getText().toString().equals("")) {
//					Toast.makeText(SettingActivity.this, "��Ȧ���벻��Ϊ��", Toast.LENGTH_SHORT).show();
//					et_singleDistance.setText("0.52");
//					
//				}
//					singleDistance=Float.parseFloat(et_singleDistance.getText().toString());
//					et_samplingInterval.setText(String.valueOf(singleDistance*numberOfPulse/singlePulse));
//								
//				return false;
//			}
//		});
		
		et_singlePulse.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				int numberOfPulse=Integer.parseInt(et_numberOfPulse.getText().toString());
				int singlePulse=Integer.parseInt(et_singlePulse.getText().toString());
				float singleDistance=Float.parseFloat(et_singleDistance.getText().toString());
				if (actionId==EditorInfo.IME_ACTION_DONE) {
					if (Integer.parseInt(et_singlePulse.getText().toString())<=0) {
						Toast.makeText(SettingActivity.this, "��Ȧ�������Ϊ������0�ķǸ���", Toast.LENGTH_SHORT).show();
						et_singlePulse.setText("100");
					}else if (et_singlePulse.getText().toString().equals("")) {
						Toast.makeText(SettingActivity.this, "��Ȧ���岻��Ϊ��", Toast.LENGTH_SHORT).show();
						et_singlePulse.setText("100");
					}
					
					tv_none.setFocusable(true);
					tv_none.setFocusableInTouchMode(true);
					tv_none.requestFocus();
					
					singlePulse=Integer.parseInt(et_singlePulse.getText().toString());
					et_samplingInterval.setText(String.valueOf(singleDistance*numberOfPulse/singlePulse));
				}
				return false;
			}
		});
		
		et_singlePulse.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if (hasFocus) {
					
				}else {
					InputMethodManager imm = (InputMethodManager) getSystemService(SettingActivity.INPUT_METHOD_SERVICE);
	                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
					Intent intent = new Intent(SettingActivity.this,NoneActivity.class);
					startActivity(intent);
				}
			}
		});
		
//		et_singlePulse.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				// TODO Auto-generated method stub
//				int numberOfPulse=Integer.parseInt(et_numberOfPulse.getText().toString());
//				int singlePulse=Integer.parseInt(et_singlePulse.getText().toString());
//				float singleDistance=Float.parseFloat(et_singleDistance.getText().toString());
//				if (Integer.parseInt(et_singlePulse.getText().toString())==0) {
//					Toast.makeText(SettingActivity.this, "��Ȧ���岻��Ϊ0", Toast.LENGTH_SHORT).show();
//					et_singlePulse.setText("100");
//				}else if (et_singlePulse.getText().toString().equals("")) {
//					Toast.makeText(SettingActivity.this, "��Ȧ���岻��Ϊ��", Toast.LENGTH_SHORT).show();
//					et_singlePulse.setText("100");
//				}
//					singlePulse=Integer.parseInt(et_singlePulse.getText().toString());
//					et_samplingInterval.setText(String.valueOf(singleDistance*numberOfPulse/singlePulse));
//				
//				
//				return false;
//			}
//		});
		
		//���򴥷���ʽ����¼�
//		sp_oneWay.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
//
//			@Override
//			public void onItemSelected(AdapterView<?> parent, View view,
//					int position, long id) {
//				// TODO Auto-generated method stub
//				switch (position) {
//				case 1:					
//					pOrders.setValiddirection((byte)0);
//					break;
//				case 2:
//					pOrders.setValiddirection((byte)1);
//					break;
//				default:
//					break;
//				}
//				new Thread(new Runnable() {
//					
//					@Override
//					public void run() {
//						// TODO Auto-generated method stub
//						pOrders.send();
//					}
//				}).start();
//			}
//
//			@Override
//			public void onNothingSelected(AdapterView<?> parent) {
//				// TODO Auto-generated method stub
//				
//			}
//		});
		
		//Ƶ�ʵ���¼�
		sp_frequency.setOnItemSelectedListener(new Spinner.OnItemSelectedListener() {
			@Override
			public void onItemSelected(AdapterView<?> parent, View view,
					int position, long id) {
				// TODO Auto-generated method stub
				frequency=Integer.parseInt(adapterOfFrequency.getItem(position).toString());
				mainPeremeterOrdersEditor.putInt("index_frequency", position);
				if (frequency==10) {
					pOrders.setFrequency((short) 0x0a00);
				}else if (frequency==20) {
					pOrders.setFrequency((short) 0x1400);
				}else if (frequency==30) {
					pOrders.setFrequency((short) 0x1e00);
				}else if (frequency==40) {
					pOrders.setFrequency((short) 0x2800);
				}else if (frequency==50) {
					pOrders.setFrequency((short) 0x3200);
				}
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						try {
							pOrders.send();
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						
					}
				}).start();
				
			}
			
			@Override
			public void onNothingSelected(AdapterView<?> parent) {
				// TODO Auto-generated method stub
				
			}
		});
		
		et_timeWindow.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				if (actionId==EditorInfo.IME_ACTION_DONE) {
					if (et_timeWindow.getText().toString().equals("")) {
						Toast.makeText(SettingActivity.this, "ʱ�䴰����Ϊ��", Toast.LENGTH_SHORT).show();
						et_timeWindow.setText("70");
					}else if (Integer.parseInt(et_timeWindow.getText().toString())<=0) {
						Toast.makeText(SettingActivity.this, "ʱ�䴰����Ϊ������0�ķǸ���", Toast.LENGTH_SHORT).show();
						et_timeWindow.setText("70");
					}
					
					
					tv_none.setFocusable(true);
					tv_none.setFocusableInTouchMode(true);
					tv_none.requestFocus();
					
				
					pOrders.setM_time_wnd(Short.parseShort(et_timeWindow.getText().toString()));
					new Thread(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							
							try {
								pOrders.send();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}).start();					
				}
				
				return false;
			}
		});		
		et_timeWindow.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if (hasFocus) {
					
				}else {
					InputMethodManager imm = (InputMethodManager) getSystemService(SettingActivity.INPUT_METHOD_SERVICE);
	                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
					Intent intent = new Intent(SettingActivity.this,NoneActivity.class);
					startActivity(intent);
				}
			}
		});
		
//		et_timeWindow.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				// TODO Auto-generated method stub	
//				if (et_timeWindow.getText().toString().equals("")) {
//						Toast.makeText(SettingActivity.this, "ʱ�䴰����Ϊ��", Toast.LENGTH_SHORT).show();
//						et_timeWindow.setText("70");
//					}else if (Integer.parseInt(et_timeWindow.getText().toString())==0) {
//						Toast.makeText(SettingActivity.this, "ʱ�䴰����Ϊ0", Toast.LENGTH_SHORT).show();
//						et_timeWindow.setText("70");
//					}
//					
//					
//				if (event.getAction()==event.ACTION_UP){
//						
//						pOrders.setM_time_wnd(Short.parseShort(et_timeWindow.getText().toString()));
//						new Thread(new Runnable() {
//							
//							@Override
//							public void run() {
//								// TODO Auto-generated method stub
//								
//								try {
//									pOrders.send();
//								} catch (Exception e) {
//									// TODO Auto-generated catch block
//									e.printStackTrace();
//								}
//							}
//						}).start();
//					} 					
//				
//				return false;
//				
//			}
//		});
		
//		et_delay.setOnKeyListener(new OnKeyListener() {
//			
//			@Override
//			public boolean onKey(View v, int keyCode, KeyEvent event) {
//				// TODO Auto-generated method stub
//				if (et_delay.getText().toString().equals("")) {
//					Toast.makeText(SettingActivity.this, "��ʱ����Ϊ��", Toast.LENGTH_SHORT).show();
//					et_delay.setText("2000");
//				}else if (Integer.parseInt(et_delay.getText().toString())<0) {
//					Toast.makeText(SettingActivity.this, "��ʱ����Ϊ�Ǹ���", Toast.LENGTH_SHORT).show();
//					et_delay.setText("2000");
//				}
//
//				if (event.getAction()==event.ACTION_UP) {
//					
//					pOrders.setDelay_time_DELAY(Short.parseShort(et_delay.getText().toString()));
//					new Thread(new Runnable() {
//						
//						@Override
//						public void run() {
//							// TODO Auto-generated method stub
//							try {
//								pOrders.send();
//							} catch (Exception e) {
//								// TODO Auto-generated catch block
//								e.printStackTrace();
//							}
//							
//						}
//					}).start();
//				}
//				
//				return false;
//			}
//		});
		et_delay.setOnEditorActionListener(new OnEditorActionListener() {
			
			@Override
			public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
				// TODO Auto-generated method stub
				if (actionId==EditorInfo.IME_ACTION_DONE) {
					if (et_delay.getText().toString().equals("")) {
						Toast.makeText(SettingActivity.this, "��ʱ����Ϊ��", Toast.LENGTH_SHORT).show();
						et_delay.setText("2000");
					}else if (Integer.parseInt(et_delay.getText().toString())<=0) {
						Toast.makeText(SettingActivity.this, "��ʱ����Ϊ������0�ķǸ���", Toast.LENGTH_SHORT).show();
						et_delay.setText("2000");
					}
					
					tv_none.setFocusable(true);
					tv_none.setFocusableInTouchMode(true);
					tv_none.requestFocus();
					
					pOrders.setDelay_time_DELAY(Short.parseShort(et_delay.getText().toString()));
					new Thread(new Runnable() {
						
						@Override
						public void run() {
							// TODO Auto-generated method stub
							try {
								pOrders.send();
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
							
						}
					}).start();
				}
				return false;
			}
		});
		et_delay.setOnFocusChangeListener(new OnFocusChangeListener() {
			
			@Override
			public void onFocusChange(View v, boolean hasFocus) {
				// TODO Auto-generated method stub
				if (hasFocus) {
					
				}else {
					InputMethodManager imm = (InputMethodManager) getSystemService(SettingActivity.INPUT_METHOD_SERVICE);
	                imm.hideSoftInputFromWindow(getWindow().getDecorView().getWindowToken(), 0);
					Intent intent = new Intent(SettingActivity.this,NoneActivity.class);
					startActivity(intent);
				}
			}
		});
			
		
		
		
		//�ӿڻص������������
		leftFragmentOfSettingActivity.setCallBackGainData(new CallBackGainData() {
			
			@Override
			public void gainData(int[] gaindata,float [] xRaw) {
				// TODO Auto-generated method stub
				System.arraycopy(gaindata, 0, gainData, 0, gaindata.length);
				System.arraycopy(xRaw, 0, SettingActivity.this.xRaw, 0, xRaw.length);
			}
		});
	}

	private void init() throws Exception {
		// TODO Auto-generated method stub
		MainActivity.readThread.setHandler(handlerOfColour);
		pOrders=new MainPeremeterOrders(MainActivity.ds);
		
		//�ս���SettingActivity���Ϳ�ʼ������������Ľ���
		rightFragmentOfSettingActivity=(RightFragmentOfSettingActivity) getFragmentManager().findFragmentById(R.id.fr_settingActivity_right);
		leftFragmentOfSettingActivity=(LeftFragmentOfSettingActivity) getFragmentManager().findFragmentById(R.id.fr_settingActivity_left);
		btn_creatPath=(Button) findViewById(R.id.btn_creatPath);
		tv_settingPath=(TextView) findViewById(R.id.tv_settingPath);
		et_nameOfMainFile=(EditText) findViewById(R.id.et_nameOfMainFile);
		et_serialNumberOfFile=(EditText) findViewById(R.id.et_serialNumberOfFile);
		tv_storeFile=(TextView) findViewById(R.id.tv_storeFile);
		sp_frequency=(Spinner) findViewById(R.id.sp_frequency);
		tv_none=(TextView) findViewById(R.id.tv_none);
//		sp_oneWay=(Spinner) findViewById(R.id.sp_oneWay);
		et_timeWindow=(EditText) findViewById(R.id.et_timeWindow);
		et_delay=(EditText) findViewById(R.id.et_delay);
		rd_timing=(RadioButton) findViewById(R.id.rb_timing);
		rd_wheel=(RadioButton) findViewById(R.id.rb_wheel);
		rd_oneWay=(RadioButton) findViewById(R.id.rb_oneWay);
		rd_twoWays=(RadioButton) findViewById(R.id.rb_twoWays);
		et_numberOfPulse=(EditText) findViewById(R.id.et_numberOfPulse);
		et_singlePulse=(EditText) findViewById(R.id.et_singlePulse);
		et_singleDistance=(EditText) findViewById(R.id.et_singleDistance);
		et_samplingInterval=(EditText) findViewById(R.id.et_samplingInterval);
		
		
		
//		sp_oneWay.setEnabled(false);
		rd_oneWay.setEnabled(false);
		rd_twoWays.setEnabled(false);
		et_numberOfPulse.setEnabled(false);
		et_singleDistance.setEnabled(false);
		et_singlePulse.setEnabled(false);
		et_samplingInterval.setEnabled(false);
		
		SharedPreferences shareXRaw=getSharedPreferences("xRaw", 0);
		SharedPreferences shareGainData=getSharedPreferences("gainData", 0);
		mainPeremeterOrders=getSharedPreferences("mainPeremeterOrders", 0);
		mainPeremeterOrdersEditor=mainPeremeterOrders.edit();
		
		//��ʼ��������ʽspinner����
//		listOfTheWayOfPulse=new ArrayList<String>();
//		listOfTheWayOfPulse.add(" ");
//		listOfTheWayOfPulse.add("����");
//		listOfTheWayOfPulse.add("����");
//		adapterOfTheWayOfPulse=new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, listOfTheWayOfPulse);
//		sp_oneWay.setAdapter(adapterOfTheWayOfPulse);
				
		//�ļ��������кš����ļ������洢·����ֵ
//		Map<String,?> key_Value=(Map<String, ?>) mainPeremeterOrders.getAll();
//		Toast.makeText(this, key_Value.size()+"", Toast.LENGTH_SHORT).show();
//		Toast.makeText(this, mainPeremeterOrders.getString("nameOfMainFile", "file"), Toast.LENGTH_LONG).show();
		et_nameOfMainFile.setText(mainPeremeterOrders.getString("nameOfMainFile", "file"));
		et_serialNumberOfFile.setText(mainPeremeterOrders.getInt("serialNumberOfFile", 1)+"");
		tv_storeFile.setText(et_nameOfMainFile.getText().toString()+et_serialNumberOfFile.getText().toString()+type);
		tv_settingPath.setText(mainPeremeterOrders.getString("path", " "));
		
		
		//��ʼ��Ƶ��spinner����
		listOfFrequency=new ArrayList<Integer>();
		listOfFrequency.add(10);
		listOfFrequency.add(20);
		listOfFrequency.add(30);
		listOfFrequency.add(40);
		listOfFrequency.add(50);
		adapterOfFrequency=new ArrayAdapter<Integer>(this, android.R.layout.simple_spinner_dropdown_item, listOfFrequency);
		sp_frequency.setAdapter(adapterOfFrequency);
		//�Դ�ȡ��spinnerλ����ΪĬ��ֵ
		sp_frequency.setSelection(mainPeremeterOrders.getInt("index_frequency", 0), true);
		frequency=Integer.parseInt(adapterOfFrequency.getItem(mainPeremeterOrders.getInt("index_frequency", 0)).toString());
		if (frequency==10) {
			pOrders.setFrequency((short) 0x0a00);
		}else if (frequency==20) {
			pOrders.setFrequency((short) 0x1400);
		}else if (frequency==30) {
			pOrders.setFrequency((short) 0x1e00);
		}else if (frequency==40) {
			pOrders.setFrequency((short) 0x2800);
		}else if (frequency==50) {
			pOrders.setFrequency((short) 0x3200);
		}
		
		et_numberOfPulse.setText(String.valueOf(500));
		et_singlePulse.setText(String.valueOf(500));
		et_singleDistance.setText(String.valueOf(0.30));
		et_samplingInterval.setText(String.valueOf(calculateSamplingInterval()));
		et_timeWindow.setText(mainPeremeterOrders.getString("timeWindow", "10"));
		et_delay.setText(mainPeremeterOrders.getString("delay", "100"));
		
		
		
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				nOrders=new NormalOrders();
					//���Ϳ�ʼ��������
					while(true){
						if (MainActivity.readThread.getJudge_startSetting()!=0) {
							MainActivity.readThread.setJudge_startSetting(0);
							break;
						}else {
							try {
								nOrders.send(startSetting,MainActivity.ds);
								Thread.sleep(100);
							} catch (Exception e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					}
					
					//�������ò���
					try {
						pOrders.setTriggerMode(0);
						pOrders.setTriggerDirection(-1);
						pOrders.setTriggerpulsenum((byte)20);
//						pOrders.setFilename("file1.raw".getBytes());
						pOrders.setTriggerdistance(2);
						pOrders.setM_time_wnd(Short.parseShort(et_timeWindow.getText().toString()));
						pOrders.setDelay_time_DELAY(Short.parseShort(et_delay.getText().toString()));
						pOrders.send();						
					} catch (Exception e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
				}
		}).start();
		
	
		for (int i = 0; i < Const_NumberOfXRawDatas; i++) {
			xRaw[i]=shareXRaw.getFloat(i+"", 10);
		}
		for (int i = 0; i <Const_NumberOfVerticalDatas; i++) {
			gainData[i]=shareGainData.getInt(i+"", 1);
		}
		leftFragmentOfSettingActivity.setXRaw(xRaw);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.setting, menu);
		return true;
	}
	
	
	public double calculateSamplingInterval(){
		return Double.parseDouble(et_singleDistance.getText().toString())/(Integer.parseInt(et_singlePulse.getText().toString())/Integer.parseInt(et_numberOfPulse.getText().toString()));
	}
	//ˮƽ���水ť����¼�
//	public void btn_horizongtalGain(View view){
//		switch (counteOfHorizontalGain%5) {
//		case 0:
//			for (int i = 0; i < Const_NumberOfXRawDatas; i++) {
//				xRaw[i]=502;
//			}
//			break;
//		case 1:
//			for (int i = 0; i < Const_NumberOfXRawDatas; i++) {
//				xRaw[i]=246;
//			}
//			break;
//		case 2:
//			for (int i = 0; i < Const_NumberOfXRawDatas; i++) {
//				xRaw[i]=118;
//			}
//			break;
//		case 3:
//			for (int i = 0; i < Const_NumberOfXRawDatas; i++) {
//				xRaw[i]=54;
//			}
//			break;
//		case 4:
//			for (int i = 0; i < Const_NumberOfXRawDatas; i++) {
//				xRaw[i]=22;
//			}
//			break;
//		default:
//			break;
//		}
//		leftFragmentOfSettingActivity.setXRaw(xRaw);
//		counteOfHorizontalGain++;
//	}
	
	
	//�������水ť����¼�
//	public void btn_stableKGain(View view){
//		for (int i = 0; i < Const_NumberOfXRawDatas; i++) {
//			xRaw[i]=10+30*i;
//		}
//		leftFragmentOfSettingActivity.setXRaw(xRaw);
//	}

	public void btn_sure(View view){
		
		
		
		if (tv_settingPath.getText().toString().equals("")) {
			Toast.makeText(this, "·������Ϊ��", Toast.LENGTH_SHORT).show();
		}else {
			path=tv_settingPath.getText().toString();
			file=new File(path+"/"+tv_storeFile.getText().toString());
//			if (pOrders.getTriggerMode()==(byte)1&&pOrders.getTriggerDirection()==(byte)-1){
//				Toast.makeText(this, "�������ִ����Ƿ�ѡ������", Toast.LENGTH_SHORT).show();
//			} 
			if (file.exists()) {
				AlertDialog.Builder builder=new AlertDialog.Builder(SettingActivity.this);
				builder.setIcon(R.drawable.warning);
				builder.setTitle("����");
				builder.setMessage("���ļ��������и��ļ����Ƿ񸲸�?");
				builder.setPositiveButton("ȷ��", new OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						if (file.exists()&&file.isFile()) {
							if (file.delete()) {
								
								Toast.makeText(SettingActivity.this, "���ǳɹ���", Toast.LENGTH_LONG).show();
							}
						}
						
						SharedPreferences.Editor shareGainData=getSharedPreferences("gainData", 0).edit();
						SharedPreferences.Editor shareXRaw=getSharedPreferences("xRaw", 0).edit();
						SharedPreferences.Editor shareJudge=getSharedPreferences("judge", 0).edit();
						
						for (int i = 0; i < Const_NumberOfVerticalDatas; i++) {
							shareGainData.putInt(i+"", gainData[i]);
						}
						for (int i = 0; i < 17; i++) {
							shareXRaw.putFloat(i+"", xRaw[i]);
						}
						shareJudge.putBoolean("judge", true);
						mainPeremeterOrdersEditor.putString("timeWindow",et_timeWindow.getText().toString() );
						mainPeremeterOrdersEditor.putString("delay", et_delay.getText().toString());
						mainPeremeterOrdersEditor.putString("path", path);
						mainPeremeterOrdersEditor.putString("frequency",frequency+"");
						mainPeremeterOrdersEditor.putString("nameOfMainFile", et_nameOfMainFile.getText().toString());
						mainPeremeterOrdersEditor.putInt("serialNumberOfFile", Integer.parseInt(et_serialNumberOfFile.getText().toString()));
						shareGainData.commit();
						shareXRaw.commit();
						shareJudge.commit();
						mainPeremeterOrdersEditor.commit();
						
						//����ֹͣ�ɼ�����
						new Thread(new Runnable() {
							
							@Override
							public void run() {
								// TODO Auto-generated method stub
								
								try {
									nOrders.send(endSetting, MainActivity.ds);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}).start();
						MainActivity.writeThread.setPath(path+"/"+tv_storeFile.getText().toString());
						MainActivity.writeThread.setSample_wnd(Integer.parseInt(et_timeWindow.getText().toString()));
						MainActivity.writeThread.setTimedelay(Short.parseShort(et_delay.getText().toString()));
						
						finish();
						
					}
				});
				
				builder.setNegativeButton("ȡ��", new OnClickListener() {
					
					@Override
					public void onClick(DialogInterface dialog, int which) {
						// TODO Auto-generated method stub
						
					}
				});
				builder.show();
			}else {
				try {
					file.createNewFile();
				} catch (IOException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				//��settingActivity�ϴ洢gainData[],��mainActivity�ж�ȡ
				SharedPreferences.Editor shareGainData=getSharedPreferences("gainData", 0).edit();
				SharedPreferences.Editor shareXRaw=getSharedPreferences("xRaw", 0).edit();
				SharedPreferences.Editor shareJudge=getSharedPreferences("judge", 0).edit();
				
				for (int i = 0; i < Const_NumberOfVerticalDatas; i++) {
					shareGainData.putInt(i+"", gainData[i]);
				}
				for (int i = 0; i < 17; i++) {
					shareXRaw.putFloat(i+"", xRaw[i]);
				}
				shareJudge.putBoolean("judge", true);
				mainPeremeterOrdersEditor.putString("timeWindow",et_timeWindow.getText().toString() );
				mainPeremeterOrdersEditor.putString("delay", et_delay.getText().toString());
				mainPeremeterOrdersEditor.putString("path", path);
				mainPeremeterOrdersEditor.putString("frequency",frequency+"");
				mainPeremeterOrdersEditor.putString("nameOfMainFile", et_nameOfMainFile.getText().toString());
				mainPeremeterOrdersEditor.putInt("serialNumberOfFile", Integer.parseInt(et_serialNumberOfFile.getText().toString()));
				
				shareGainData.commit();
				shareXRaw.commit();
				shareJudge.commit();
				mainPeremeterOrdersEditor.commit();
				
				//����ֹͣ�ɼ�����
				new Thread(new Runnable() {
					
					@Override
					public void run() {
						// TODO Auto-generated method stub
						
						try {
							nOrders.send(endSetting, MainActivity.ds);
						} catch (Exception e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
					}
				}).start();
				MainActivity.writeThread.setPath(path+"/"+tv_storeFile.getText().toString());
				MainActivity.writeThread.setSample_wnd(Integer.parseInt(et_timeWindow.getText().toString()));
				MainActivity.writeThread.setTimedelay(Short.parseShort(et_delay.getText().toString()));
				
				finish();
				
			}
		}
	}
	
	//����·����ť����¼�
	public void btn_creatPath(View view){
		calendar=Calendar.getInstance();
		mYear=calendar.get(Calendar.YEAR);
		mMonth=calendar.get(Calendar.MONTH) + 1;
		mDay=calendar.get(Calendar.DAY_OF_MONTH);
		mHour=calendar.get(Calendar.HOUR_OF_DAY);
		mMinute=calendar.get(Calendar.MINUTE);
		String creatFolderName="data"+"-"+mYear+"-"+mMonth+"-"+mDay+"-"+mHour+"-"+mMinute;
		File creatFolder=new File(defaultPath, creatFolderName);
		if (!creatFolder.exists()) {
			creatFolder.mkdirs();
			path=defaultPath+"/"+creatFolderName;
			tv_settingPath.setText(path.toString());
//			path=path+"/"+tv_storeFile.getText().toString();
		}
		
	}
	
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		if(FILE_RESULT_CODE == requestCode){  
            Bundle bundle = null;  
            if(data!=null&&(bundle=data.getExtras())!=null){  
            	path=bundle.getString("file");
                tv_settingPath.setText(path);  
//                path=path+"/"+tv_storeFile.getText().toString();
            }  
        }  
	}
	
	//����·����ť����¼�
	public void btn_settingPath(View view){
		 Intent intent = new Intent(SettingActivity.this,MyFileManager.class);  
         startActivityForResult(intent, FILE_RESULT_CODE);
	}
	
	public void btn_automaticSetting(View view){
		judge_automaticSetting=!judge_automaticSetting;
		new Thread(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				while (judge_automaticSetting) {
					
					try {
						handlerOfColour.sendEmptyMessage(1);
						Thread.sleep(100);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
			}
		}).start();

	}
	
	
	
	@Override
	protected void onDestroy() {
		// TODO Auto-generated method stub
		super.onDestroy();

		
	}
	
	@Override
	public boolean dispatchKeyEvent(KeyEvent event) {
		// TODO Auto-generated method stub
		 if (event.getKeyCode() == KeyEvent.KEYCODE_BACK) {//������Ƿ��ؼ�  
	            if (event.getAction() == KeyEvent.ACTION_DOWN && event.getRepeatCount() == 0) {//�����İ����¼�  
	            	new Thread(new Runnable() {
	        			
	        			@Override
	        			public void run() {
	        				// TODO Auto-generated method stub
	        				
	        				try {
	        					nOrders.send(endSetting, MainActivity.ds);
	        				} catch (Exception e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	        			}
	        		}).start(); 
	            } else if (event.getAction() == KeyEvent.ACTION_UP && event.getRepeatCount() == 0) {//������̧���¼�  
	            }  
	        }  
		return super.dispatchKeyEvent(event);
	}
	
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		// TODO Auto-generated method stub
		super.onWindowFocusChanged(hasFocus);
		if (hasFocus) {
			getWindow().getDecorView().setSystemUiVisibility(
	                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
	                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
	                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
	                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
	                        | View.SYSTEM_UI_FLAG_FULLSCREEN
	                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
	    
		}
	}
	
//	 public static void NavigationBarStatusBar(Activity activity,boolean hasFocus){
//	        if (hasFocus ) {
//	            View decorView = activity.getWindow().getDecorView();
//	            decorView.setSystemUiVisibility(
//	                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE
//	                            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
//	                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
//	                            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//	                            | View.SYSTEM_UI_FLAG_FULLSCREEN
//	                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
//	        }
//	 }

	
//	protected void hideBottomUIMenu() {
//        //�������ⰴ��������ȫ��
//        if (Build.VERSION.SDK_INT > 11 && Build.VERSION.SDK_INT < 19) { // lower api
//            View v = this.getWindow().getDecorView();
//            v.setSystemUiVisibility(View.GONE);
//        } else if (Build.VERSION.SDK_INT >= 19) {
//            //for new api versions.
//            View decorView = getWindow().getDecorView();
//            int uiOptions = View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
//                            | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN;
//            decorView.setSystemUiVisibility(uiOptions);
//        }
//    }
	
	
	
	
}
