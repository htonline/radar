package com.example.helper;

import java.util.ArrayList;
import java.util.List;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiConfiguration;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.text.TextUtils;
import android.util.Log;

public class WifiTool {
    // ������Context����
    private Context mContext;
    // WifiManager����
    private WifiManager mWifiManager;

    public WifiTool(Context mContext) {
        this.mContext = mContext;
        mWifiManager = (WifiManager) mContext
                .getSystemService(Context.WIFI_SERVICE);
    }

    /**
     * �ж��ֻ��Ƿ�������Wifi��
     */
    public boolean isConnectWifi() {
        // ��ȡConnectivityManager����
        ConnectivityManager conMgr = (ConnectivityManager) mContext
                .getSystemService(Context.CONNECTIVITY_SERVICE);
        // ��ȡNetworkInfo����
        NetworkInfo info = conMgr.getActiveNetworkInfo();
        // ��ȡ���ӵķ�ʽΪwifi
        State wifi = conMgr.getNetworkInfo(ConnectivityManager.TYPE_WIFI)
                .getState();

        if (info != null && info.isAvailable() && wifi == State.CONNECTED)

        {
            return true;
        } else {
            return false;
        }

    }

    /**
     * ��ȡ��ǰ�ֻ������ӵ�wifi��Ϣ
     */
    public WifiInfo getCurrentWifiInfo() {
        return mWifiManager.getConnectionInfo();
    }

    /**
     * ����һ�����粢����
     * ���������WIFI����������WifiConfiguration
     */
    public boolean addNetwork(WifiConfiguration wcg) {
        int wcgID = mWifiManager.addNetwork(wcg);
        return mWifiManager.enableNetwork(wcgID, true);
    }

    /**
     * �����������ȵ���Ϣ�������������ȵ�Ϊ��Ϣ��SSID��������
     */
    public List<String> getScanSSIDsResult() {
        // ɨ����ȵ�����
        List<ScanResult> resultList;
        // ��ʼɨ���ȵ�
        mWifiManager.startScan();
        resultList = mWifiManager.getScanResults();
        ArrayList<String> ssids = new ArrayList<String>();
        if (resultList != null) {
            for (ScanResult scan : resultList) {
                ssids.add(scan.SSID);// �������ݣ�ȡ��ssid���ݼ�
            }
        }
        return ssids;
    }

    /**
     * �õ��ֻ���������ssid���ϣ������жϳ��豸��ssid��dssid��
     */
    public List<String> accordSsid() {
        List<String> s = getScanSSIDsResult();
        List<String> result = new ArrayList<String>();
        for (String str : s) {
            if (checkDssid(str)) {
                result.add(str);
            }
        }
        return result;
    }

    /**
     * ���ָ��ssid�ǲ���ƥ���ssid��Ŀǰ֧��GBELL��TOP,���������ӡ�
     * 
     * @param ssid
     * @return
     */
    private boolean checkDssid(String ssid) {
        if (!TextUtils.isEmpty(ssid)) {
        //�������������Լ����������жϣ�������������д��һ������
            if (ssid.length() > 8 ) {
                return true;
            }
            else {
                return false;
            }
        } else {
            return false;
        }
    }

    private boolean OpenWifi() {
        boolean bRet = true;
        if(!mWifiManager.isWifiEnabled()) {
            bRet = mWifiManager.setWifiEnabled(true);
        }
        return bRet;
    }
    
    
    
    /**
     * ����wifi
     * ������wifi��ssid��wifi������
     */
    public boolean connectWifiTest(final String ssid, final String pwd) {
        boolean isSuccess = false;
        boolean flag = false;
        boolean flag2=false;
        if (mWifiManager.getWifiState()==1) {			
        	OpenWifi();
		}
      
        boolean addSucess=false;
        while (!flag2) {
			int a=mWifiManager.getWifiState();
			if (a==3) {
				flag2=true;
				addSucess = addNetwork(CreateWifiInfo(ssid, pwd, 3));
			}
		}
     
       
        
        try {
			Thread.sleep(8000);
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
//        mWifiManager.disconnect();
        if (addSucess) {
            while (!flag && !isSuccess) {
            	//getCurrentWifiInfo()ʹ�õ�ǰ�����Ѿ�������wifi������ǰ��˯��8s������������Ȼ�����ж�
                String currSSID = getCurrentWifiInfo().getSSID();
                currSSID=getCurrentWifiInfo().getSSID();
                if (currSSID != null)
                    currSSID = currSSID.replace("\"", "");
//                int currIp = getCurrentWifiInfo().getIpAddress();
//                Log.d("----------",currIp+"" );
                if (currSSID != null && currSSID.equals(ssid)) {
        //���ﻹ��Ҫ���Ż���������ǿ����ж� 
                    isSuccess = true;
                } else {
                    flag = true;
                }
            }
        }
        return isSuccess;

    }

    /**
     * ����WifiConfiguration����
     * ��Ϊ���������1û������;2��wep����;3��wpa����
     * @param SSID
     * @param Password
     * @param Type
     * @return
     */
    public WifiConfiguration CreateWifiInfo(String SSID, String Password,
            int Type) {
        WifiConfiguration config = new WifiConfiguration();
        config.allowedAuthAlgorithms.clear();
        config.allowedGroupCiphers.clear();
        config.allowedKeyManagement.clear();
        config.allowedPairwiseCiphers.clear();
        config.allowedProtocols.clear();
        config.SSID = "\"" + SSID + "\"";

        WifiConfiguration tempConfig = this.IsExsits(SSID);
        if (tempConfig != null) {
            mWifiManager.removeNetwork(tempConfig.networkId);
        }

        if (Type == 1) // WIFICIPHER_NOPASS
        {
            config.wepKeys[0] = "";
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            config.wepTxKeyIndex = 0;
        }
        if (Type == 2) // WIFICIPHER_WEP
        {
            config.hiddenSSID = true;
            config.wepKeys[0] = "\"" + Password + "\"";
            config.allowedAuthAlgorithms
                    .set(WifiConfiguration.AuthAlgorithm.SHARED);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.WEP40);
            config.allowedGroupCiphers
                    .set(WifiConfiguration.GroupCipher.WEP104);
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.NONE);
            config.wepTxKeyIndex = 0;
        }
        if (Type == 3) // WIFICIPHER_WPA
        {
            config.preSharedKey = "\"" + Password + "\"";
            config.hiddenSSID = true;
            config.allowedAuthAlgorithms
                    .set(WifiConfiguration.AuthAlgorithm.OPEN);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.TKIP);
            config.allowedKeyManagement.set(WifiConfiguration.KeyMgmt.WPA_PSK);
            config.allowedPairwiseCiphers
                    .set(WifiConfiguration.PairwiseCipher.TKIP);
            // config.allowedProtocols.set(WifiConfiguration.Protocol.WPA);
            config.allowedGroupCiphers.set(WifiConfiguration.GroupCipher.CCMP);
            config.allowedPairwiseCiphers
                    .set(WifiConfiguration.PairwiseCipher.CCMP);
            config.status = WifiConfiguration.Status.ENABLED;
        }
        return config;
    }

    private WifiConfiguration IsExsits(String SSID) {
        List<WifiConfiguration> existingConfigs = mWifiManager
                .getConfiguredNetworks();
        for (WifiConfiguration existingConfig : existingConfigs) {
            if (existingConfig.SSID.equals("\"" + SSID + "\"")) {
                return existingConfig;
            }
        }
        return null;
    }
    
    
}
