package com.example.interfaces;

public interface OnUpActionListener {
	public void onUp(int [] gainData,float [] xRaw);

}
