package com.example.thread;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;

import android.R.integer;

public class WriteThread implements Runnable {

	public Thread t;
	private String path=null;
	private int judgeNumber=0;
	private boolean judgePause = false;
	private boolean judgeStart=true;
	private boolean judgeIfRepeat=false;
	private static final int Const_NumberOfVerticalDatas = 512;
	private short colorGap[] = new short[Const_NumberOfVerticalDatas];
	private int sample_wnd;
	private short timedelay;
	private int trace_num=100;
	FileOutputStream fos = null;
	BufferedOutputStream bos = null;
	RandomAccessFile raf=null;
//	private final ByteBuffer buffer=ByteBuffer.allocate(1024);
//	private FileChannel fChannel=null;
	
	byte [] line_position=new byte [36];
	byte [] nouse=new byte [157];

	
	
	public int getSample_wnd() {
		return sample_wnd;
	}

	public void setSample_wnd(int sample_wnd) {
		this.sample_wnd = sample_wnd;
	}

	public short getTimedelay() {
		return timedelay;
	}

	public void setTimedelay(short timedelay) {
		this.timedelay = timedelay;
	}

	public int getTrace_num() {
		return trace_num;
	}

	public void setTrace_num(int trace_num) {
		this.trace_num = trace_num;
	}

	public int getJudgeNumber() {
		return judgeNumber;
	}

	public void setJudgeNumber(int judgeNumber) {
		this.judgeNumber = judgeNumber;
	}

	public boolean isJudgePause() {
		return judgePause;
	}

	public void setJudgePause(boolean judgePause) {
		this.judgePause = judgePause;
	}

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public short[] getColorGap() {
		return colorGap;
	}

	public void setColorGap(short[] colorGap) {
		this.colorGap = colorGap;
	}

	public boolean isJudgeStart() {
		return judgeStart;
	}

	public void setJudgeStart(boolean judgeStart) {
		this.judgeStart = judgeStart;
	}

	public boolean isJudgeIfRepeat() {
		return judgeIfRepeat;
	}

	public void setJudgeIfRepeat(boolean judgeIfRepeat) {
		this.judgeIfRepeat = judgeIfRepeat;
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		while (judgeStart) {
			if (path != null) {
				switch (judgeNumber) {
				case 1:

					
//					try {
//						fos=new FileOutputStream(path);
//						bos=new BufferedOutputStream(fos);
//						try {
//							bos.write("yf  ".getBytes());
//							bos.write(int2byte(sample_wnd));
//							bos.write(int2byte(trace_num));
//							bos.write(int2byte(512));
//							bos.write(int2byte(0));
//							bos.write(int2byte(1));
//							bos.write(line_position);
//							bos.write(shortToByte((short)1));
//							bos.write(shortToByte((short)512));
//							bos.write(shortToByte((short)0));
//							bos.write(shortToByte(timedelay));
//							bos.write(shortToByte((short)1));
//							bos.write(shortToByte((short)0));
//							bos.write(int2byte(0));
//							bos.write(floatToByte((float)1));
//							bos.write(shortToByte((short)0));
//							bos.write("  ".getBytes());
//							bos.write(nouse);
//							bos.flush();
//						} catch (IOException e) {
//							// TODO Auto-generated catch block
//							e.printStackTrace();
//						}
//						
//					} catch (FileNotFoundException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
					
					try {
						raf=new RandomAccessFile(path, "rw");
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					try {						
						raf.write("yf  ".getBytes());
						raf.write(int2byte(sample_wnd));
						raf.write(int2byte(trace_num));
						raf.write(int2byte(512));
						raf.write(int2byte(0));
						raf.write(int2byte(1));
						raf.write(line_position);
						raf.write(shortToByte((short)1));
						raf.write(shortToByte((short)512));
						raf.write(shortToByte((short)0));
						raf.write(shortToByte(timedelay));
						raf.write(shortToByte((short)1));
						raf.write(shortToByte((short)0));
						raf.write(int2byte(0));
						raf.write(floatToByte((float)1));
						raf.write(shortToByte((short)0));
						raf.write("  ".getBytes());
						raf.write(nouse);
					} catch (IOException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					}
					
					judgeNumber++;
					break;
				case 2:
					break;
				case 3:					
						if (!judgeIfRepeat) {
							try {
								
								for (int i = 0; i < Const_NumberOfVerticalDatas; i++) {
									raf.write(shortToByte(colorGap[i]));
//									bos.write(shortToByte(colorGap[i]));
								}
//								bos.flush();
				
								judgeIfRepeat=true;
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}
						}
					
					break;
				case 4:
//					try {
//						raf=new RandomAccessFile(path, "rw");
//					} catch (FileNotFoundException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
//					try {						
//						raf.write("yf  ".getBytes());
//						raf.write(int2byte(sample_wnd));
//						raf.write(int2byte(trace_num));
//						raf.write(int2byte(512));
//						raf.write(int2byte(0));
//						raf.write(int2byte(1));
//						raf.write(line_position);
//						raf.write(shortToByte((short)1));
//						raf.write(shortToByte((short)512));
//						raf.write(shortToByte((short)0));
//						raf.write(shortToByte(timedelay));
//						raf.write(shortToByte((short)1));
//						raf.write(shortToByte((short)0));
//						raf.write(int2byte(0));
//						raf.write(floatToByte((float)1));
//						raf.write(shortToByte((short)0));
//						raf.write("  ".getBytes());
//						raf.write(nouse);
//					} catch (IOException e1) {
//						// TODO Auto-generated catch block
//						e1.printStackTrace();
//					}
					break;
				default:
					break;
				}
			}
		}
	}

	 /**
     * ��ʼ
     */
    public void start(){
        
        if(t==null){
            t=new Thread(this);
            t.start();
        }
    }
    
  
    
    public void stop(){
    	try {
    		judgeStart=false;
			raf.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	setJudgeStart(false);
    }
	
	public static byte[] shortToByte(short number) { 
        int temp = number; 
        byte[] b = new byte[2]; 
        for (int i = 0; i < b.length; i++) { 
            b[i] = new Integer(temp & 0xff).byteValue();
            //�����λ���������λ 
            temp = temp >> 8; // ������8λ 
        } 
        return b; 
    } 
	
	 /** 
	  * ����ת��Ϊ�ֽ� 
	  *  
	  * @param f 
	  * @return 
	  */  
	 public static byte[] floatToByte(float f) {  
	       
	     // ��floatת��Ϊbyte[]  
	     int fbit = Float.floatToIntBits(f);  
	       
	     byte[] b = new byte[4];    
	     for (int i = 0; i < 4; i++) {    
	         b[i] = (byte) (fbit >> (24 - i * 8));    
	     }   
	       
	     // ��ת����  
	     int len = b.length;  
	     // ����һ����Դ����Ԫ��������ͬ������  
	     byte[] dest = new byte[len];  
	     // Ϊ�˷�ֹ�޸�Դ���飬��Դ���鿽��һ�ݸ���  
	     System.arraycopy(b, 0, dest, 0, len);  
	     byte temp;  
	     // ��˳λ��i���뵹����i������  
	     for (int i = 0; i < len / 2; ++i) {  
	         temp = dest[i];  
	         dest[i] = dest[len - i - 1];  
	         dest[len - i - 1] = temp;  
	     }  
	       
	     return dest;  
	       
	 }  
	 public static byte[] int2byte(int res) {
			byte[] targets = new byte[4];
			
			targets[0] = (byte) (res & 0xff);// ���λ
			targets[1] = (byte) ((res >> 8) & 0xff);// �ε�λ
			targets[2] = (byte) ((res >> 16) & 0xff);// �θ�λ
			targets[3] = (byte) (res >>> 24);// ���λ,�޷������ơ�
			return targets;
		}
	
}
