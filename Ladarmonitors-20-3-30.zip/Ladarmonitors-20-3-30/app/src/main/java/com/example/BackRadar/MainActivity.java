package com.example.BackRadar;

import java.io.File;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Timer;
import com.example.customizingViews.ColoursView;
import com.example.customizingViews.RadarView;
import com.example.fragments.LeftFragmentOfMainActivity;
import com.example.fragments.RightFragmentOfMainActivity;
import com.example.helper.WifiConnect;
import com.example.helper.WifiTool;
import com.example.helper.WifiConnect.WifiCipherType;
import com.example.ladarmonitor.R;
import com.example.orders.NormalOrders;
import com.example.thread.JudgeHaveThread;
import com.example.thread.JudgeMetalThread;
import com.example.thread.ReadThread;
import com.example.thread.WriteThread;

import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.provider.Settings;
import android.provider.Settings.Global;

import android.R.integer;
import android.R.string;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
	public static final String defaultPath="/sdcard/datas";
	private String path=null;
	FragmentManager fManager=null;
	private LeftFragmentOfMainActivity lFragment;
//	private RightFragmentOfMainActivity rFragment;
	private ImageButton ibtn_startAndSuspend;
	private ImageButton ibtn_wifi;
	private ImageButton ibtn_setting;
	private ImageButton ibtn_stop;
	private ImageButton ibtn_upload;
	private ColoursView coloursView=null;
	private RadarView radarView=null;
	private TextView tv_numberOfReceive=null;
	private TextView tv_path=null;
	private TextView tv_timeWindow=null;
	private TextView tv_frequency=null;
	private TextView tv_delay=null;
	private TextView tv_markNumber=null;

//	private TextView tv_numberOfLose=null;
	private TextView tv_logo=null;
	private Button btn_mark=null;
	//���wifi��ť������ʾ��
	ProgressDialog progressDialog;
	//���������жϼ���������ͣ
	private int counter=0;
	//�������жϿ�ʼ��ť�Ƿ�����
	private int clickOrNot=0;
	//���͸���λ��������
	NormalOrders nOrders=null;
	static ReadThread readThread=null;
	static WriteThread writeThread=null;
//	JudgeHaveThread judgeHaveThread=null;
//	JudgeMetalThread judgeMetalThread=null;

	//�ж��Ƿ�����ֹͣ��ť���������������ʼ��ť��ʱ�򵯳��Ի���ѯ���Ƿ񸲸�
	boolean judge_clickStopIbtn=false;

	//�ж��Ƿ���
	private boolean judge_MartOrNot=false;
	//�������
	private int markNumber=0;

	//�ļ����к�
	int serialNumberOfFile=0;

	static DatagramSocket ds=null;
	DatagramPacket dp=null;
	byte creatLink []={(byte) 0xaa,(byte) 0xaa,(byte) 0x01,0x00};
	byte startCollect []={(byte) 0xaa,(byte) 0xaa,(byte) 0x08,0x00};
    byte suspendCollect []={(byte) 0xaa,(byte) 0xaa,(byte) 0x10,0x00};
    byte continueCollect []={(byte) 0xaa,(byte) 0xaa,(byte) 0x20,0x00};
    byte stopCollect []={(byte) 0xaa,(byte) 0xaa,(byte) 0x40,0x00};

	//��settingActivity����ȷ���󣬻᷵��true��shareJudge���ڽ��ս��
	private SharedPreferences shareJudge=null;
	private SharedPreferences shareXRaw=null;
	private SharedPreferences shareGainData=null;
	private SharedPreferences mainPeremeterOrders=null;

	SharedPreferences.Editor mainPeremeterOrdersEditor=null;

	//��̬IP��ַ
	public static final String STATICIP="192.168.0.100";

	//�ļ�����
	public static final String type=".raw";

	//һ�����ݵĵ���
	public static final int Const_NumberOfVerticalDatas=512;
	private int colorList []=new int [Const_NumberOfVerticalDatas];
	private short colorGap []=new short [Const_NumberOfVerticalDatas];
//	private int gainData []=new int [Const_NumberOfVerticalDatas];


	//��¼��ǰ�����ǵڼ���
    private int numberOfLogo;
    //��¼ʵ���յ����ٵ�����
    private int counterOfReal;

    //��������˳������жϼ��ʱ��
    private long firstTime=0;
    //�ж���������
    private int judge_haveOrNot=-1;
	private Handler handlerOfColour=new Handler(){
        @Override
        public void handleMessage(Message msg) {
        	switch (msg.what) {
			case 0:
				colorGap=(short[]) msg.obj;
				if (judge_MartOrNot) {
					colorGap[0]=0xff;
					colorGap[1]=0xff;
					colorGap[2]=0xff;
					colorGap[3]=0xff;
				}
//				judgeHaveThread.setColorGap(colorGap);
//				judgeMetalThread.setColorGap(colorGap);
				if (judge_MartOrNot) {
					for (int i = 0; i <Const_NumberOfVerticalDatas; i++) {
						colorList[i]=0x0000ff;
						colorGap[i]=(short) (colorGap[i]/256);
					}
				}else {
					for (int i = 0; i <Const_NumberOfVerticalDatas; i++) {
						int color=(colorGap[i]+32768)/256;
						colorList[i]=Color.rgb(color, color, color);
						colorGap[i]=(short) (colorGap[i]/256);
					}
				}
				writeThread.setColorGap(colorGap);
				writeThread.setJudgeIfRepeat(false);
				writeThread.setJudgeNumber(3);

				tv_numberOfReceive.setText(msg.arg2+"");
				lFragment.drawNewVertical(colorList);
//				rFragment.drawRadarWave(colorGap,gainData);	
				judge_MartOrNot=false;
				break;
			case 1:
				ibtn_wifi.setImageResource(R.drawable.wifigreen2);
				ibtn_wifi.setEnabled(false);
				ibtn_setting.setImageResource(R.drawable.settinggreen2);
				ibtn_setting.setEnabled(true);
				break;
			case 3:
				int sum_juegeextremum7=msg.arg1;
//				int sum_extremum3=msg.arg2;
//				if (sum_extremum3>0) {
//					if (judge_haveOrNot==1) {
//						tv_metalOrNot.setText("����");
//					}else if (judge_haveOrNot==0) {
//						tv_metalOrNot.setText("δ��⵽����");
//					}
//				}else {
//					if (sum_juegeextremum5>5) {
//						tv_metalOrNot.setText("����");
//					}else {
//						if (judge_haveOrNot==1) {
//							tv_metalOrNot.setText("�ǽ���");						
//						}else if(judge_haveOrNot==0){
//							tv_metalOrNot.setText("δ��⵽����");
//						}
////					}
//				}
//				if (judge_haveOrNot==0) {
//					tv_metalOrNot.setText("δ��⵽����");
//				}else if(judge_haveOrNot==1){
//					if (sum_juegeextremum7<0) {
//						tv_metalOrNot.setText("�ǽ���");
//					}else {
//						tv_metalOrNot.setText("����");
//					}
//				}
				break;
			case 4:
				//������
				judge_haveOrNot=1;
				break;
			case 5:
				//û������
				judge_haveOrNot=0;
				break;
			case 6:
				judge_MartOrNot = true;
                markNumber++;
                tv_markNumber.setText(markNumber+"");
				colorGap=(short[]) msg.obj;
				if (judge_MartOrNot) {
					colorGap[0]=0xff;
					colorGap[1]=0xff;
					colorGap[2]=0xff;
					colorGap[3]=0xff;
				}
//				judgeHaveThread.setColorGap(colorGap);
//				judgeMetalThread.setColorGap(colorGap);
				if (judge_MartOrNot) {
					for (int i = 0; i <Const_NumberOfVerticalDatas; i++) {
						colorList[i]=0x0000ff;
						colorGap[i]=(short) (colorGap[i]/256);
					}}
				writeThread.setColorGap(colorGap);
				writeThread.setJudgeIfRepeat(false);
				writeThread.setJudgeNumber(3);

				lFragment.drawNewVertical(colorList);
//				rFragment.drawRadarWave(colorGap,gainData);
				judge_MartOrNot=false;
				break;
			default:
				break;
			}
        }
    };



	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		getWindow().setFlags(WindowManager.LayoutParams. FLAG_FULLSCREEN ,
                WindowManager.LayoutParams. FLAG_FULLSCREEN);
		 getWindow().setFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
	                WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
		setContentView(R.layout.activity_main);
		fManager=getFragmentManager();
		init();
		ibtn_startAndSuspend.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				//��һ�ε��������Ƭ
				clickOrNot++;

				if (judge_clickStopIbtn) {
					AlertDialog.Builder builder=new AlertDialog.Builder(MainActivity.this);
					builder.setIcon(R.drawable.warning);
					builder.setTitle("����");
					builder.setMessage("�Ƿ񸲸�ԭ�ļ�?");
					builder.setPositiveButton("ȷ��", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub
							File file=new File(tv_path.getText().toString());
							if (file.exists()&&file.isFile()) {
								if (file.delete()) {
									try {
										file.createNewFile();
									} catch (IOException e) {
										// TODO Auto-generated catch block
										e.printStackTrace();
									}
									Toast.makeText(MainActivity.this, "���ǳɹ�����ʼ�ɼ���", Toast.LENGTH_LONG).show();
								}
							}
							if (counter==0) {
								lFragment=new LeftFragmentOfMainActivity();
//								rFragment=new RightFragmentOfMainActivity();
								//��������
								FragmentTransaction fTransaction=fManager.beginTransaction();
								//������Ƭ
								fTransaction.add(R.id.fl_containerLeft, lFragment);
//								fTransaction.add(R.id.fl_containerRight, rFragment);
								//��Ƭ���ӵ�����ջ
								fTransaction.addToBackStack(null);
								//�ύ
								fTransaction.commit();
							}

							//ż�����ͻ�����ͣ
							//��һ�ε����ȡ�����߳�������ͬʱ�����������λ����ʼ�ɼ�����
							if (counter==0) {
								writeThread.setJudgeNumber(1);
								readThread.setNumberOfReceive(0);
								//���Դ��
								btn_mark.setEnabled(true);
								new Thread(new Runnable() {

									@Override
									public void run() {
										// TODO Auto-generated method stub
										try {
											nOrders.send(startCollect, ds);
										} catch (Exception e) {
											// TODO Auto-generated catch block
											e.printStackTrace();
										}
									}
								}).start();

								ibtn_startAndSuspend.setImageResource(R.drawable.suspend2);
							}



							ibtn_setting.setImageResource(R.drawable.settinggray2);
							ibtn_stop.setImageResource(R.drawable.stopred2);
							ibtn_stop.setEnabled(true);
							ibtn_setting.setEnabled(false);
							counter++;
							judge_clickStopIbtn=false;
						}
					});

					builder.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {

						@Override
						public void onClick(DialogInterface dialog, int which) {
							// TODO Auto-generated method stub

						}
					});

					builder.show();

				}else {
					if (counter==0) {
						File file=new File(tv_path.getText().toString());
						if (!file.exists()) {

							try {
								file.createNewFile();
							} catch (IOException e) {
								// TODO Auto-generated catch block
								e.printStackTrace();
							}


						}
						lFragment=new LeftFragmentOfMainActivity();
//						rFragment=new RightFragmentOfMainActivity();
						//��������
						FragmentTransaction fTransaction=fManager.beginTransaction();
						//������Ƭ
						fTransaction.add(R.id.fl_containerLeft, lFragment);
//						fTransaction.add(R.id.fl_containerRight, rFragment);
						//��Ƭ���ӵ�����ջ
						fTransaction.addToBackStack(null);
						//�ύ
						fTransaction.commit();
					}

					//ż�����ͻ�����ͣ
					//��һ�ε����ȡ�����߳�������ͬʱ�����������λ����ʼ�ɼ�����
					if (counter==0) {
						writeThread.setJudgeNumber(1);
						readThread.setNumberOfReceive(0);
						//���Դ��
						btn_mark.setEnabled(true);
						new Thread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								try {
									nOrders.send(startCollect, ds);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}).start();

						ibtn_startAndSuspend.setImageResource(R.drawable.suspend2);
					}
					//���˵�һ�ε����ż���Σ��ָ���ȡ���ݣ����͸���λ����������
					if (counter%2==0&&counter!=0) {
						readThread.resume();
						btn_mark.setEnabled(true);
//						writeThread.setJudgePause(false);
						new Thread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								try {
									nOrders.send(continueCollect, ds);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}).start();

						ibtn_startAndSuspend.setImageResource(R.drawable.suspend2);

					}
					//��������ͣ����λ����ȡ���ݣ�ͬʱ����λ������������ͣ����
					if (counter%2==1) {
						btn_mark.setEnabled(false);
						readThread.suspend();
//						writeThread.setJudgePause(true);
						new Thread(new Runnable() {

							@Override
							public void run() {
								// TODO Auto-generated method stub
								try {
									nOrders.send(suspendCollect, ds);
								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}).start();
						ibtn_startAndSuspend.setImageResource(R.drawable.startgreen2);
					}

					ibtn_setting.setImageResource(R.drawable.settinggray2);
					ibtn_stop.setImageResource(R.drawable.stopred2);
					ibtn_stop.setEnabled(true);
					ibtn_setting.setEnabled(false);
					counter++;

				}

			}
		});
	}

	private void init() {
		// TODO Auto-generated method stub
		ibtn_startAndSuspend=(ImageButton) findViewById(R.id.ibtn_startAndSuspend);
		ibtn_wifi=(ImageButton) findViewById(R.id.ibtn_wifi);
		ibtn_setting=(ImageButton) findViewById(R.id.ibtn_setting);
		ibtn_stop=(ImageButton) findViewById(R.id.ibtn_stop);
		ibtn_upload=(ImageButton)findViewById(R.id.ibtn_upload);
		tv_numberOfReceive=(TextView) findViewById(R.id.tv_numberOfReceive);
		tv_path=(TextView) findViewById(R.id.tv_path);
		tv_timeWindow=(TextView) findViewById(R.id.tv_timeWindow);
		tv_frequency=(TextView) findViewById(R.id.tv_frequency);
		tv_delay=(TextView) findViewById(R.id.tv_delay);
		tv_markNumber=(TextView) findViewById(R.id.tv_markNumber);
		tv_logo=(TextView) findViewById(R.id.tv_logo);
		Typeface typeface=Typeface.createFromAsset(getAssets(), "PlayfairDisplay-Bold.ttf");
		tv_logo.setTypeface(typeface);
		btn_mark=(Button) findViewById(R.id.btn_mark);
		ibtn_startAndSuspend.setImageResource(R.drawable.startgray2);
		ibtn_wifi.setImageResource(R.drawable.wifigray2);
		ibtn_wifi.setEnabled(true);
		ibtn_setting.setImageResource(R.drawable.settinggray2);
		ibtn_stop.setImageResource(R.drawable.stopgray2);
		ibtn_stop.setEnabled(false);
		ibtn_upload.setImageResource(R.drawable.upload);
		btn_mark.setEnabled(false);
		ibtn_setting.setEnabled(false);



		//ͨ������ı��ĸ�ͼƬ��ť�Ŀ��ȣ����óɺ͸߶ȴ�Сһ��
		DisplayMetrics dm = getResources().getDisplayMetrics();
		int height = dm.heightPixels;
		int width=dm.widthPixels;
//		tv_numberOfLose.setText(height+"");
//		tv_numberOfReceive.setText(width+"");
		LinearLayout.LayoutParams ibtn_settingLinearParams =(LinearLayout.LayoutParams) ibtn_setting.getLayoutParams();
		ibtn_settingLinearParams.width=height/8;
		ibtn_setting.setLayoutParams(ibtn_settingLinearParams);
		LinearLayout.LayoutParams ibtn_startAndSuspendLinearParams =(LinearLayout.LayoutParams) ibtn_startAndSuspend.getLayoutParams();
		ibtn_startAndSuspendLinearParams.width=height/8;
		ibtn_setting.setLayoutParams(ibtn_startAndSuspendLinearParams);
		LinearLayout.LayoutParams ibtn_wifiLinearParams =(LinearLayout.LayoutParams) ibtn_wifi.getLayoutParams();
		ibtn_wifiLinearParams.width=height/8;
		ibtn_setting.setLayoutParams(ibtn_wifiLinearParams);
		LinearLayout.LayoutParams ibtn_stopLinearParams =(LinearLayout.LayoutParams) ibtn_stop.getLayoutParams();
		ibtn_stopLinearParams.width=height/8;
		ibtn_setting.setLayoutParams(ibtn_stopLinearParams);
		LinearLayout.LayoutParams ibtn_uploadLinearParams =(LinearLayout.LayoutParams) ibtn_upload.getLayoutParams();
		ibtn_uploadLinearParams.width=height/8;
		ibtn_setting.setLayoutParams(ibtn_uploadLinearParams);

		shareJudge=getSharedPreferences("judge", 0);
		shareXRaw=getSharedPreferences("xRaw", 0);

		try {
			try {
				ds=new DatagramSocket(8080);
			} catch (SocketException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					nOrders.send(stopCollect, ds);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
		nOrders=new NormalOrders();
		readThread=new ReadThread(ds);
		readThread.setHandler(handlerOfColour);
		readThread.start();
		writeThread=new WriteThread();
		writeThread.start();

//		judgeHaveThread=new JudgeHaveThread(this,handlerOfColour);
//		judgeHaveThread.start();
//		judgeMetalThread=new JudgeMetalThread(handlerOfColour);
//		judgeMetalThread.start();

	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}


	//��갴ť����¼�
	public void btnMark(View view){
		judge_MartOrNot=true;
		markNumber++;
		tv_markNumber.setText(markNumber+"");
	}

	//ֹͣ��ť����¼�����λ��ֹͣ�������ݣ���Ƭ��ջ,������counter�ָ�Ϊ0��
	public void stopIbtn(View view){
		new Thread(new Runnable() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				try {
					nOrders.send(stopCollect, ds);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
		fManager.popBackStack();
		judge_clickStopIbtn=true;
		ibtn_stop.setImageResource(R.drawable.stopgray2);
		ibtn_stop.setEnabled(false);
		ibtn_startAndSuspend.setImageResource(R.drawable.startgreen2);
		ibtn_setting.setEnabled(true);
		ibtn_setting.setImageResource(R.drawable.settinggreen2);
		btn_mark.setEnabled(false);
		counter=0;
		//���������
		markNumber=0;
		tv_markNumber.setText(markNumber+"");

		//�ж��Ƿ�����ʼ��ͣ��ť��0
		clickOrNot=0;
		writeThread.setTrace_num(Integer.parseInt(tv_numberOfReceive.getText().toString()));
		writeThread.setJudgeNumber(1);
//		writeThread.stop();

//		judgeHaveThread.setJudge_NumberOfData(0);
		//�������ͣ������µ���ֹͣ�����̻߳ᴦ������״̬���ٴε����ʼ���ղ������ݣ���Ҫ����
		readThread.resume();
	}

	public void uploadIbtn(View view){
		final AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("���ϴ��ļ�");
		dialog.setMessage("��ѡ���ļ�·���Լ���Ӧ���ļ�");
		
		dialog.setPositiveButton("�ϴ�", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int i) {
				Toast.makeText(MainActivity.this,"�ϴ��ɹ�",Toast.LENGTH_SHORT).show();
			}
		});
		dialog.setNegativeButton("ȡ��", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int i) {
				Toast.makeText(MainActivity.this,"�˳�",Toast.LENGTH_SHORT).show();
			}
		});
		dialog.show();
		Toast.makeText(this,"eddd",Toast.LENGTH_SHORT).show();
	}

	//���ð�ť�ĵ���¼�
	public void settingIbtn(View view){
		if (clickOrNot>0||judge_clickStopIbtn) {
			mainPeremeterOrdersEditor.putInt("serialNumberOfFile", ++serialNumberOfFile);
			mainPeremeterOrdersEditor.commit();
//			Map<String,?> key_Value=(Map<String, ?>) mainPeremeterOrders.getAll();
//			Toast.makeText(this, key_Value.size()+"", Toast.LENGTH_SHORT).show();
		}
		Intent intent=new Intent(MainActivity.this, SettingActivity.class);
		startActivity(intent);
	}

	//wifi�ĵ���¼�
	public void wifiIbtn(View view){


		ConnectivityManager connectivityManager= (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo wifiNetworkInfo= connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
//		WifiManager wifiManager = (WifiManager) getSystemService(WIFI_SERVICE);  
//		WifiInfo wifiInfo = wifiManager.getConnectionInfo(); 
//		String ssid=wifiInfo.getSSID();

	     //���wifi�Ƿ��Ѿ��������磬����Ѿ�������ip��ַ�ԣ���ʾ�Ѿ����ӣ�������ת��wifi���ӽ���
		if (wifiNetworkInfo.isConnected()) {
			WifiManager wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
			WifiInfo wifiInfo = wifiManager.getConnectionInfo();
			String ipAddress=intIP2StringIP(wifiInfo.getIpAddress());
			if (ipAddress.equals(STATICIP)) {
				Toast.makeText(this, "���ӳɹ���", Toast.LENGTH_LONG).show();
				new Thread(new Runnable() {
					@Override
					public void run() {
						// TODO Auto-generated method stub
						while (true) {

							if (readThread.getJudge_creatLink()!=0) {
								readThread.setJudge_creatLink(0);
								handlerOfColour.sendEmptyMessage(1);
								break;
							}else {
								try {
									Thread.sleep(100);
									nOrders.send(creatLink, ds);

								} catch (Exception e) {
									// TODO Auto-generated catch block
									e.printStackTrace();
								}
							}
						}
					}
				}).start();
			}else {
				Toast.makeText(this, "�������ӵ�wifi�Ƿ���ȷ", Toast.LENGTH_LONG).show();
				Intent intent = new Intent();
				intent.setAction("android.net.wifi.PICK_WIFI_NETWORK");
				startActivity(intent);
			}
//			ibtn_wifi.setImageResource(R.drawable.wifigreen2);

//			Toast.makeText(MainActivity.this, "�Ѿ�����", Toast.LENGTH_LONG).show();
		}else {
			Toast.makeText(this, "��������wifi", Toast.LENGTH_LONG).show();
			Intent intent = new Intent();
			intent.setAction("android.net.wifi.PICK_WIFI_NETWORK");
			startActivity(intent);

		}

	}

	private  String intIP2StringIP(int ip) {
        return (ip & 0xFF) + "." +
                ((ip >> 8) & 0xFF) + "." +
                ((ip >> 16) & 0xFF) + "." +
                (ip >> 24 & 0xFF);
    }



	//����settingActivity���˳�����ϵͳ���Զ�����������������԰���Ҫ�ı��ܲ��ܵ�����¼���������
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
//		Log.e("--------------", "onresume");
		shareGainData=getSharedPreferences("gainData", 0);
//		for (int i = 0; i <Const_NumberOfVerticalDatas; i++) {
//			gainData[i]=shareGainData.getInt(i+"", 1);
//		}
		ibtn_startAndSuspend.setEnabled(shareJudge.getBoolean("judge", false));
		readThread.setHandler(handlerOfColour);

		if (shareJudge.getBoolean("judge", false)) {
			//�ٴ����ú������жϲ���
			judge_clickStopIbtn=false;

			mainPeremeterOrders=getSharedPreferences("mainPeremeterOrders", 0);
			mainPeremeterOrdersEditor=mainPeremeterOrders.edit();
//			Toast.makeText(this, "path:"+mainPeremeterOrders.getString("path", "gwh/11")
//					+"\n timeWindow:"+mainPeremeterOrders.getString("timeWindow", "1")
//					+"\n frequncy:"+mainPeremeterOrders.getString("frequency", "1")
//					+"\n delay:"+mainPeremeterOrders.getString("delay", "100"), Toast.LENGTH_LONG).show();
			serialNumberOfFile=mainPeremeterOrders.getInt("serialNumberOfFile", 0);
			tv_path.setText(mainPeremeterOrders.getString("path", " ")+"/"+mainPeremeterOrders.getString("nameOfMainFile", "error")+mainPeremeterOrders.getInt("serialNumberOfFile", 0)+type);
			tv_timeWindow.setText(mainPeremeterOrders.getString("timeWindow", "1"));
			tv_frequency.setText(mainPeremeterOrders.getString("frequency", "1"));
			tv_delay.setText(mainPeremeterOrders.getString("delay", "100"));
			ibtn_startAndSuspend.setImageResource(R.drawable.startgreen2);
			readThread.setNumberOfReceive(0);

		}
		super.onResume();
	}



	//˫�����ؼ��˳����棬������м�¼������Ϊ�˷�ֹ�ڲɼ����ݵ�ʱ���˳�Ӳ����Ȼ�ڲ����ݣ��˳���ʱ����Ҫ����ֹͣ�ɼ�����
	//���û�е����ʼ��ť��������⵼�������ؼ�����ʾ˫���˳�����������ʼ�ɼ���ť�������ؼ�����ʾ�Ƿ񱣴����ݣ�ȷ����������
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		// TODO Auto-generated method stub
		 if(keyCode==KeyEvent.KEYCODE_BACK && event.getAction()==KeyEvent.ACTION_DOWN){
	            if (System.currentTimeMillis()-firstTime>2000){
	                Toast.makeText(MainActivity.this,"�ٴε�����ؼ��˳�����",Toast.LENGTH_SHORT).show();
	                firstTime=System.currentTimeMillis();

	            }else{
	            	//����ֹͣ�ɼ�����
//	            	Toast.makeText(this,"else",Toast.LENGTH_SHORT).show();
	            	new Thread(new Runnable() {

	        			@Override
	        			public void run() {
	        				// TODO Auto-generated method stub
	        				try {
	        					nOrders.send(stopCollect, ds);
	        				} catch (Exception e) {
	        					// TODO Auto-generated catch block
	        					e.printStackTrace();
	        				}
	        			}
	        		}).start();



	        		SharedPreferences.Editor shareJudgeEditor = shareJudge.edit();
	        		SharedPreferences.Editor shareXRawEditor = shareXRaw.edit();
	        		SharedPreferences.Editor shareGainDataEditor = shareGainData.edit();
	        		shareJudgeEditor.clear();
	        		shareJudgeEditor.commit();
	        		shareXRawEditor.clear();
	        		shareXRawEditor.commit();
	        		shareGainDataEditor.clear();
	        		shareGainDataEditor.commit();
	        		mainPeremeterOrdersEditor.clear();
	        		mainPeremeterOrdersEditor.commit();
	        		//�߳�ֹͣ
	        		if (clickOrNot>0) {
						//û��ֹͣ��ťֱ���˳������ʱ��д�߳�ֹͣ
	        			writeThread.setTrace_num(Integer.parseInt(tv_numberOfReceive.getText().toString()));
	        			writeThread.setJudgeNumber(1);
		            	writeThread.stop();

					}
	        		readThread.setJudge(false);


	                finish();
	                System.exit(0);
	            }
	            return true;
	        }
	        return super.onKeyDown(keyCode, event);
	}


	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		// TODO Auto-generated method stub
		super.onWindowFocusChanged(hasFocus);
		if (hasFocus) {
			getWindow().getDecorView().setSystemUiVisibility(
	                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
	                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
	                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
	                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
	                        | View.SYSTEM_UI_FLAG_FULLSCREEN
	                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

		}
	}


}
